[CmdletBinding()]
param(
    [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$SignedVdfPath,
    [Parameter(Mandatory)][ValidatePattern('^[0-9A-Fa-f]{64}$')][string]$ExpectedSignedVdfSha256,
    [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$SentinelPath,
    [Parameter(Mandatory)][ValidatePattern('^[0-9A-Fa-f]{64}$')][string]$ExpectedSentinelSha256,
    [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$OutputRoot,
    [Parameter(Mandatory)][ValidatePattern('^[a-z0-9][a-z0-9-]{2,63}$')][string]$RunId,
    [ValidateRange(1, [uint32]::MaxValue)][uint32]$AppId = 431960,
    [string]$ControllerPath = (Join-Path $PSScriptRoot 'steam_service_host_local_control.ps1'),
    [string]$FrameModulePath = (Join-Path $PSScriptRoot 'steam_service_ipc_frames.ps1'),
    [string]$ControllerRuntimePath,
    [string]$FrameModuleRuntimePath,
    [string]$PackRuntimeRoot,
    [string]$ExpectedRequesterIdentity,
    [ValidatePattern('^S-\d(-\d+)+$')][string]$ExpectedRequesterSid,
    [ValidateSet('identity-sentinel', 'interactive-system-cmd')]
    [string]$EvidenceMode = 'identity-sentinel',
    [uint32]$ExpectedRequesterSessionId = 0,
    [string]$SteamClientPath = 'C:\Program Files (x86)\Steam\steamclient.dll',
    [ValidatePattern('^[0-9A-Fa-f]{64}$')]
    [string]$ExpectedSteamClientSha256 = 'E9E961C914A418B6A3C597822BDC920BDEA62C842FF42DE23DC306331DA563F8',
    [string]$SteamServiceExePath = 'C:\Program Files (x86)\Common Files\Steam\steamservice.exe',
    [ValidatePattern('^[0-9A-Fa-f]{64}$')]
    [string]$ExpectedSteamServiceExeSha256 = '6C451A0CDDAF71816C09E268237F8226FE32DFC1E36CE0229C5B1F425FDC8B62',
    [string]$SteamServiceDllPath = 'C:\Program Files (x86)\Common Files\Steam\SteamService.dll',
    [ValidatePattern('^[0-9A-Fa-f]{64}$')]
    [string]$ExpectedSteamServiceDllSha256 = 'FEAEC497B4BA572CD1A9D4BA9C4DD9E1952D3D9C71E50476103F76B2BBFF7A82',
    [string]$SteamExePath = 'C:\Program Files (x86)\Steam\steam.exe',
    [ValidatePattern('^[0-9A-Fa-f]{64}$')]
    [string]$ExpectedSteamExeSha256 = '48EA0576865D2DFDA26001B7B210C3F7559D46E647424CD11704EB1EA842FE5A',
    [string]$SteamWebHelperPath = 'C:\Program Files (x86)\Steam\bin\cef\cef.win64\steamwebhelper.exe',
    [ValidatePattern('^[0-9A-Fa-f]{64}$')]
    [string]$ExpectedSteamWebHelperSha256 = 'F9EE1D1CC0F06FAD16C9A277136A2E1B00B6B668901E28454A7DD8AF29AFDE0D'
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$interactiveCmdTimeoutMilliseconds = 0

function Get-HostPackSha256 {
    param([Parameter(Mandatory)][byte[]]$Bytes)
    $sha = [Security.Cryptography.SHA256]::Create()
    try { ([BitConverter]::ToString($sha.ComputeHash($Bytes))).Replace('-', '') }
    finally { $sha.Dispose() }
}

function Read-HostPackBytes {
    param([Parameter(Mandatory)][string]$Path, [int]$MaximumLength = 10485760)
    $stream = [IO.File]::Open($Path, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::Read)
    try {
        if ($stream.Length -lt 1 -or $stream.Length -gt $MaximumLength) {
            throw "Input length is outside the allowed bound: $Path"
        }
        $bytes = [byte[]]::new([int]$stream.Length)
        $offset = 0
        while ($offset -lt $bytes.Length) {
            $read = $stream.Read($bytes, $offset, $bytes.Length - $offset)
            if ($read -le 0) { throw "Unexpected end of input: $Path" }
            $offset += $read
        }
        return ,$bytes
    } finally {
        $stream.Dispose()
    }
}

function Get-HostPackFixedPath {
    param([Parameter(Mandatory)][string]$Path)
    if ($Path -notmatch '^[A-Za-z]:\\' -or $Path.Contains('/') -or $Path.IndexOf(':', 2) -ge 0) {
        throw "Path must use a local drive-letter form: $Path"
    }
    $full = [IO.Path]::GetFullPath($Path)
    $drive = [IO.Path]::GetPathRoot($full)
    if ([IO.DriveInfo]::new($drive).DriveType -ne [IO.DriveType]::Fixed) {
        throw "Path must be on a fixed local volume: $Path"
    }
    $full
}

function Test-HostPackContained {
    param([string]$Root, [string]$Candidate)
    $rootFull = (Get-HostPackFixedPath $Root).TrimEnd('\')
    $candidateFull = Get-HostPackFixedPath $Candidate
    $candidateFull -ieq $rootFull -or $candidateFull.StartsWith(
        $rootFull + '\',
        [StringComparison]::OrdinalIgnoreCase
    )
}

function Assert-HostPackNoReparse {
    param(
        [Parameter(Mandatory)][string]$Path,
        [switch]$AllowMissingLeaf
    )
    $full = Get-HostPackFixedPath $Path
    $drive = [IO.Path]::GetPathRoot($full)
    $relative = $full.Substring($drive.Length)
    $parts = @($relative.Split('\', [StringSplitOptions]::RemoveEmptyEntries))
    $current = $drive
    for ($index = 0; $index -lt $parts.Count; $index++) {
        $current = Join-Path $current $parts[$index]
        if (-not (Test-Path -LiteralPath $current)) {
            if ($AllowMissingLeaf -and $index -eq $parts.Count - 1) { return $full }
            throw "Missing path component: $current"
        }
        $item = Get-Item -LiteralPath $current -Force
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw "Reparse-point path is not allowed: $current"
        }
    }
    $full
}

function Write-HostPackNewBytes {
    param([Parameter(Mandatory)][string]$Path, [Parameter(Mandatory)][byte[]]$Bytes)
    $stream = [IO.File]::Open($Path, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
    try {
        $stream.Write($Bytes, 0, $Bytes.Length)
        $stream.Flush($true)
    } finally {
        $stream.Dispose()
    }
}

function Get-HostPackBoundFile {
    param(
        [Parameter(Mandatory)][string]$Path,
        [string]$ExpectedSha256
    )
    $full = Assert-HostPackNoReparse -Path $Path
    if (-not (Test-Path -LiteralPath $full -PathType Leaf)) { throw "Bound file is missing: $full" }
    $item = Get-Item -LiteralPath $full -Force
    $hash = (Get-FileHash -LiteralPath $full -Algorithm SHA256).Hash.ToUpperInvariant()
    if ($ExpectedSha256 -and $hash -cne $ExpectedSha256.ToUpperInvariant()) {
        throw "Bound file SHA-256 mismatch: $full"
    }
    [ordered]@{ path = $full; length = [int64]$item.Length; sha256 = $hash }
}

function New-HostRunVdf {
    param(
        [Parameter(Mandatory)][string]$RunDirectory,
        [Parameter(Mandatory)][string]$OutputPath,
        [Parameter(Mandatory)][string]$LauncherPath,
        [Parameter(Mandatory)][string]$RunKeyName,
        [Parameter(Mandatory)][uint32]$RunAppId,
        [ValidateSet('identity-sentinel', 'interactive-system-cmd')]
        [string]$EvidenceMode = 'identity-sentinel',
        [uint32]$ExpectedSessionId = 0
    )
    $hasRunKey = "HKEY_LOCAL_MACHINE\Software\Valve\Steam\Apps\$RunAppId\$RunKeyName"
    $command = '--run-dir "' + $RunDirectory + '" --output "' + $OutputPath + '"'
    if ($EvidenceMode -ceq 'interactive-system-cmd') {
        if ($ExpectedSessionId -eq 0) { throw 'Interactive evidence requires a nonzero requester session ID.' }
        $command += ' --interactive-system-cmd --expected-session-id ' + $ExpectedSessionId
    } elseif ($ExpectedSessionId -ne 0) {
        throw 'Identity-sentinel evidence cannot bind an interactive session ID.'
    }
    $hasRunKeyRaw = $hasRunKey.Replace('\', '\\')
    $launcherRaw = $LauncherPath.Replace('\', '\\')
    $commandRaw = $command.Replace('\', '\\').Replace('"', '\"')
    $text = "`"InstallScript`"`n{`n`t`"Run Process`"`n`t{`n`t`t`"$RunKeyName`"`n" +
        "`t`t{`n`t`t`t`"HasRunKey`" `"$hasRunKeyRaw`"`n" +
        "`t`t`t`"IgnoreHasRunKey`" `"1`"`n" +
        "`t`t`t`"IgnoreExitCode`" `"1`"`n" +
        "`t`t`t`"process 1`" `"$launcherRaw`"`n" +
        "`t`t`t`"command 1`" `"$commandRaw`"`n`t`t}`n`t}`n}`n"
    [pscustomobject]@{
        bytes = [Text.UTF8Encoding]::new($false).GetBytes($text)
        text = $text
        has_run_key = $hasRunKey
        process_decoded = $LauncherPath
        command_decoded = $command
    }
}

$sourcePath = Assert-HostPackNoReparse -Path $SignedVdfPath
$sentinelSource = Assert-HostPackNoReparse -Path $SentinelPath
$outputFull = Assert-HostPackNoReparse -Path $OutputRoot
if (-not (Test-Path -LiteralPath $sourcePath -PathType Leaf) -or
    -not (Test-Path -LiteralPath $sentinelSource -PathType Leaf) -or
    -not (Test-Path -LiteralPath $outputFull -PathType Container)) {
    throw 'Input VDF, sentinel, and output root must already exist.'
}

$controllerBinding = Get-HostPackBoundFile -Path $ControllerPath
$frameModuleBinding = Get-HostPackBoundFile -Path $FrameModulePath
$controllerRuntimeFull = if ([string]::IsNullOrWhiteSpace($ControllerRuntimePath)) {
    $controllerBinding.path
} else { Get-HostPackFixedPath $ControllerRuntimePath }
$frameModuleRuntimeFull = if ([string]::IsNullOrWhiteSpace($FrameModuleRuntimePath)) {
    $frameModuleBinding.path
} else { Get-HostPackFixedPath $FrameModuleRuntimePath }
if ([IO.Path]::GetFileName($controllerRuntimeFull) -cne 'steam_service_host_local_control.ps1' -or
    [IO.Path]::GetFileName($frameModuleRuntimeFull) -cne 'steam_service_ipc_frames.ps1' -or
    [IO.Path]::GetDirectoryName($controllerRuntimeFull) -cne [IO.Path]::GetDirectoryName($frameModuleRuntimeFull)) {
    throw 'Controller and frame-module runtime paths must use their fixed leaves in one directory.'
}
$requesterIdentity = [Security.Principal.WindowsIdentity]::GetCurrent()
if ([string]::IsNullOrWhiteSpace($ExpectedRequesterIdentity) -and
    [string]::IsNullOrWhiteSpace($ExpectedRequesterSid)) {
    $requesterName = $requesterIdentity.Name
    $requesterSid = $requesterIdentity.User.Value
} elseif ([string]::IsNullOrWhiteSpace($ExpectedRequesterIdentity) -or
    [string]::IsNullOrWhiteSpace($ExpectedRequesterSid) -or
    $ExpectedRequesterIdentity.IndexOf([char]0) -ge 0 -or
    $ExpectedRequesterIdentity.Trim() -cne $ExpectedRequesterIdentity) {
    throw 'Expected requester identity and SID overrides must both be canonical.'
} else {
    $parsedRequesterSid = [Security.Principal.SecurityIdentifier]::new($ExpectedRequesterSid)
    if ($parsedRequesterSid.Value -cne $ExpectedRequesterSid) { throw 'Expected requester SID is noncanonical.' }
    $requesterName = $ExpectedRequesterIdentity
    $requesterSid = $parsedRequesterSid.Value
}
if ($EvidenceMode -ceq 'interactive-system-cmd' -and $ExpectedRequesterSessionId -eq 0) {
    throw 'Interactive evidence requires a nonzero expected requester session ID.'
}
if ($EvidenceMode -ceq 'identity-sentinel' -and $ExpectedRequesterSessionId -ne 0) {
    throw 'Identity-sentinel evidence cannot bind an interactive session ID.'
}
$interactiveCmdBinding = $null
if ($EvidenceMode -ceq 'interactive-system-cmd') {
    $systemDirectory = [Environment]::SystemDirectory
    if ([string]::IsNullOrWhiteSpace($systemDirectory)) { throw 'Windows system directory is unavailable.' }
    $interactiveCmdBinding = Get-HostPackBoundFile -Path (Join-Path $systemDirectory 'cmd.exe')
}
$controllerManifestBinding = [ordered]@{
    path = $controllerRuntimeFull
    length = $controllerBinding.length
    sha256 = $controllerBinding.sha256
}
$frameModuleManifestBinding = [ordered]@{
    path = $frameModuleRuntimeFull
    length = $frameModuleBinding.length
    sha256 = $frameModuleBinding.sha256
}
$steamClientBinding = Get-HostPackBoundFile -Path $SteamClientPath -ExpectedSha256 $ExpectedSteamClientSha256
$serviceExeBinding = Get-HostPackBoundFile -Path $SteamServiceExePath -ExpectedSha256 $ExpectedSteamServiceExeSha256
$serviceDllBinding = Get-HostPackBoundFile -Path $SteamServiceDllPath -ExpectedSha256 $ExpectedSteamServiceDllSha256
$steamExeBinding = Get-HostPackBoundFile -Path $SteamExePath -ExpectedSha256 $ExpectedSteamExeSha256
$steamWebHelperBinding = Get-HostPackBoundFile -Path $SteamWebHelperPath -ExpectedSha256 $ExpectedSteamWebHelperSha256
. $frameModuleBinding.path

$signedBytes = Read-HostPackBytes $sourcePath 1048576
$sentinelBytes = Read-HostPackBytes $sentinelSource 10485760
$signedHash = Get-HostPackSha256 $signedBytes
$sentinelHash = Get-HostPackSha256 $sentinelBytes
if ($signedHash -ine $ExpectedSignedVdfSha256) { throw 'Signed VDF SHA-256 mismatch.' }
if ($sentinelHash -ine $ExpectedSentinelSha256) { throw 'Sentinel SHA-256 mismatch.' }

$strictUtf8 = [Text.UTF8Encoding]::new($false, $true)
$signedText = $strictUtf8.GetString($signedBytes)
if ($signedText.IndexOf([char]0) -ge 0 -or [Text.Encoding]::ASCII.GetString(
        [Text.Encoding]::ASCII.GetBytes($signedText)
    ) -cne $signedText) {
    throw 'Signed VDF must be NUL-free ASCII within strict UTF-8.'
}
$signaturePattern = '(?s)"kvsignatures"\s*\{\s*"InstallScript"\s*"([0-9A-Fa-f]{256})"'
$signatureMatches = [regex]::Matches($signedText, $signaturePattern)
if ($signatureMatches.Count -ne 1) { throw 'Expected exactly one 256-character InstallScript signature.' }
$signatureGroup = $signatureMatches[0].Groups[1]
$negativeBytes = [byte[]]$signedBytes.Clone()
$signatureOffset = $signatureGroup.Index
$oldByte = $negativeBytes[$signatureOffset]
$replacement = if ($oldByte -eq [byte][char]'9') { [byte][char]'A' } elseif (
    $oldByte -eq [byte][char]'F' -or $oldByte -eq [byte][char]'f'
) { [byte][char]'0' } else { [byte]($oldByte + 1) }
$negativeBytes[$signatureOffset] = $replacement
$changed = 0
for ($index = 0; $index -lt $signedBytes.Length; $index++) {
    if ($signedBytes[$index] -ne $negativeBytes[$index]) { $changed++ }
}
if ($changed -ne 1) { throw 'Signature-negative input did not change exactly one byte.' }

$runRoot = Join-Path $outputFull $RunId
if (-not (Test-HostPackContained $outputFull $runRoot)) { throw 'Run root escaped output root.' }
Assert-HostPackNoReparse -Path $runRoot -AllowMissingLeaf | Out-Null
if (Test-Path -LiteralPath $runRoot) { throw "Run root already exists: $runRoot" }
[void][IO.Directory]::CreateDirectory($runRoot)
$runtimeRoot = if ([string]::IsNullOrWhiteSpace($PackRuntimeRoot)) {
    $runRoot
} else { Get-HostPackFixedPath $PackRuntimeRoot }
if ([IO.Path]::GetPathRoot($runtimeRoot) -ceq $runtimeRoot -or $runtimeRoot.EndsWith('\')) {
    throw 'Pack runtime root must be a canonical non-root directory path without a trailing separator.'
}

$signedDirectory = Join-Path $runRoot 'signed-input'
$negativeDirectory = Join-Path $runRoot 'signature-negative'
$noWhitelistRoot = Join-Path $runRoot 'no-whitelist'
$relocatedRoot = Join-Path $runRoot 'relocated-root'
$evidenceDirectory = Join-Path $runRoot 'evidence'
$noWhitelistEvidence = Join-Path $evidenceDirectory 'no-whitelist'
$relocatedEvidence = Join-Path $evidenceDirectory 'relocated'
$runtimeNoWhitelistRoot = Join-Path $runtimeRoot 'no-whitelist'
$runtimeRelocatedRoot = Join-Path $runtimeRoot 'relocated-root'
$runtimeSignedCopy = Join-Path $runtimeRoot 'signed-input\installscript.vdf'
$runtimeNegativeCopy = Join-Path $runtimeRoot 'signature-negative\installscript-one-byte-signature.vdf'
$runtimeNoWhitelistVdf = Join-Path $runtimeNoWhitelistRoot 'unsigned-run.vdf'
$runtimeRelocatedVdf = Join-Path $runtimeRelocatedRoot 'unsigned-run.vdf'
$runtimeEvidenceDirectory = Join-Path $runtimeRoot 'evidence'
$runtimeNoWhitelistEvidence = Join-Path $runtimeEvidenceDirectory 'no-whitelist'
$runtimeRelocatedEvidence = Join-Path $runtimeEvidenceDirectory 'relocated'
foreach ($directory in @(
    $signedDirectory,
    $negativeDirectory,
    $noWhitelistRoot,
    $relocatedRoot,
    $evidenceDirectory,
    $noWhitelistEvidence,
    $relocatedEvidence
)) {
    [void][IO.Directory]::CreateDirectory($directory)
    Assert-HostPackNoReparse -Path $directory | Out-Null
}

$signedCopy = Join-Path $signedDirectory 'installscript.vdf'
$negativeCopy = Join-Path $negativeDirectory 'installscript-one-byte-signature.vdf'
$noWhitelistLauncher = Join-Path $noWhitelistRoot 'launcher.exe'
$noWhitelistVdf = Join-Path $noWhitelistRoot 'unsigned-run.vdf'
$relocatedLauncher = Join-Path $relocatedRoot 'launcher.exe'
$relocatedVdf = Join-Path $relocatedRoot 'unsigned-run.vdf'
$noWhitelistOutput = Join-Path $noWhitelistEvidence 'sentinel.json'
$relocatedOutput = Join-Path $relocatedEvidence 'sentinel.json'
$runtimeNoWhitelistOutput = Join-Path $runtimeNoWhitelistEvidence 'sentinel.json'
$runtimeRelocatedOutput = Join-Path $runtimeRelocatedEvidence 'sentinel.json'
$noWhitelistRun = New-HostRunVdf -RunDirectory $runtimeNoWhitelistEvidence -OutputPath $runtimeNoWhitelistOutput -LauncherPath (Join-Path $runtimeNoWhitelistRoot 'launcher.exe') -RunKeyName 'HostNoWhitelistControl' -RunAppId $AppId
$relocatedRun = New-HostRunVdf -RunDirectory $runtimeRelocatedEvidence -OutputPath $runtimeRelocatedOutput -LauncherPath (Join-Path $runtimeRelocatedRoot 'launcher.exe') -RunKeyName 'HostRelocatedSentinel' -RunAppId $AppId -EvidenceMode $EvidenceMode -ExpectedSessionId $ExpectedRequesterSessionId

Write-HostPackNewBytes $signedCopy $signedBytes
Write-HostPackNewBytes $negativeCopy $negativeBytes
Write-HostPackNewBytes $noWhitelistLauncher $sentinelBytes
Write-HostPackNewBytes $noWhitelistVdf $noWhitelistRun.bytes
Write-HostPackNewBytes $relocatedLauncher $sentinelBytes
Write-HostPackNewBytes $relocatedVdf $relocatedRun.bytes

$filePaths = [ordered]@{
    'signed-input\installscript.vdf' = $signedCopy
    'signature-negative\installscript-one-byte-signature.vdf' = $negativeCopy
    'no-whitelist\launcher.exe' = $noWhitelistLauncher
    'no-whitelist\unsigned-run.vdf' = $noWhitelistVdf
    'relocated-root\launcher.exe' = $relocatedLauncher
    'relocated-root\unsigned-run.vdf' = $relocatedVdf
}
$files = foreach ($entry in $filePaths.GetEnumerator()) {
    $bytes = Read-HostPackBytes $entry.Value 10485760
    [ordered]@{ relative_path = $entry.Key; length = $bytes.Length; sha256 = Get-HostPackSha256 $bytes }
}

$negativeWhitelistPayload = New-IpcWhitelistPayload -SignedVdfPath $runtimeNegativeCopy -InstallRoot $runtimeRelocatedRoot -SelectorForm CurrentClient
$positiveWhitelistPayload = New-IpcWhitelistPayload -SignedVdfPath $runtimeSignedCopy -InstallRoot $runtimeRelocatedRoot -SelectorForm CurrentClient
$noWhitelistRunPayload = New-IpcRunPayload -VdfPath $runtimeNoWhitelistVdf -Argument $AppId -WireBoolean $false -SelectorForm CurrentClient
$relocatedRunPayload = New-IpcRunPayload -VdfPath $runtimeRelocatedVdf -Argument $AppId -WireBoolean $false -SelectorForm CurrentClient
$queryPayload = Get-IpcQueryPayload -SelectorForm CurrentClient
$frozenFrames = [ordered]@{
    negative_whitelist = New-IpcFrame $negativeWhitelistPayload
    positive_whitelist = New-IpcFrame $positiveWhitelistPayload
    no_whitelist_run = New-IpcFrame $noWhitelistRunPayload
    relocated_run = New-IpcFrame $relocatedRunPayload
    query = New-IpcFrame $queryPayload
}
$activePolicy = [ordered]@{
    active_ipc_allowed = $true
    game_launch_permitted = $false
    interactive_steam_client_required = $true
    steam_service_mutation_permitted = $false
    allowed_case_order = @(
        'signature-negative',
        'signed-whitelist-positive',
        'relocated-chain-sentinel',
        'pre-no-whitelist-baseline',
        'no-whitelist-negative'
    )
    allowed_methods = @('AddInstallScriptToWhiteList', 'RunInstallScript', 'GetInstallScriptExitCode')
}
if ($EvidenceMode -ceq 'interactive-system-cmd') {
    $activePolicy['evidence_mode'] = $EvidenceMode
    $activePolicy['interactive_system_cmd_permitted'] = $true
    $activePolicy['interactive_system_cmd_lifetime'] = 'until-user-exit'
    $activePolicy['interactive_system_cmd_timeout_milliseconds'] = $interactiveCmdTimeoutMilliseconds
    $activePolicy['interactive_system_cmd_job_cleanup_required'] = $true
}
$activePolicyBytes = [Text.UTF8Encoding]::new($false).GetBytes(($activePolicy | ConvertTo-Json -Depth 6 -Compress))
$packSchema = if ($EvidenceMode -ceq 'interactive-system-cmd') {
    'steam-service-host-local-pack/v3'
} else {
    'steam-service-host-local-pack/v2'
}
$manifest = [ordered]@{
    schema = $packSchema
    run_id = $RunId
    created_at_utc = [DateTime]::UtcNow.ToString('o')
    pack_root = $runtimeRoot
    evidence_directory = $runtimeEvidenceDirectory
    active_policy = $activePolicy
    expected_requester = [ordered]@{
        identity = $requesterName
        sid = $requesterSid
    }
    tooling = [ordered]@{
        controller = $controllerManifestBinding
        frame_module = $frameModuleManifestBinding
        selector_form = 'CurrentClient'
        frame_sha256 = [ordered]@{
            negative_whitelist = Get-IpcSha256 $frozenFrames.negative_whitelist
            positive_whitelist = Get-IpcSha256 $frozenFrames.positive_whitelist
            no_whitelist_run = Get-IpcSha256 $frozenFrames.no_whitelist_run
            relocated_run = Get-IpcSha256 $frozenFrames.relocated_run
            query = Get-IpcSha256 $frozenFrames.query
        }
    }
    target = [ordered]@{
        steam_client = $steamClientBinding
        service_exe = $serviceExeBinding
        service_dll = $serviceDllBinding
        steam_exe = $steamExeBinding
        steam_webhelper = $steamWebHelperBinding
    }
    source = [ordered]@{ signed_vdf_path = $sourcePath; sentinel_path = $sentinelSource }
    signed_vdf = [ordered]@{
        relative_path = 'signed-input\installscript.vdf'
        length = $signedBytes.Length
        sha256 = $signedHash
    }
    negative_signature = [ordered]@{
        relative_path = 'signature-negative\installscript-one-byte-signature.vdf'
        length = $negativeBytes.Length
        source_sha256 = $signedHash
        sha256 = Get-HostPackSha256 $negativeBytes
        offset_zero_based = $signatureOffset
        original_byte_hex = '{0:X2}' -f $oldByte
        replacement_byte_hex = '{0:X2}' -f $replacement
        changed_byte_count = $changed
    }
    run = [ordered]@{
        app_id = $AppId
        wire_boolean = $false
        no_whitelist = [ordered]@{
            vdf_relative_path = 'no-whitelist\unsigned-run.vdf'
            vdf_sha256 = Get-HostPackSha256 $noWhitelistRun.bytes
            launcher_relative_path = 'no-whitelist\launcher.exe'
            launcher_sha256 = $sentinelHash
            output_path = $runtimeNoWhitelistOutput
            process_decoded = $noWhitelistRun.process_decoded
            has_run_key = $noWhitelistRun.has_run_key
            command_decoded = $noWhitelistRun.command_decoded
        }
        relocated = [ordered]@{
            vdf_relative_path = 'relocated-root\unsigned-run.vdf'
            vdf_sha256 = Get-HostPackSha256 $relocatedRun.bytes
            launcher_relative_path = 'relocated-root\launcher.exe'
            launcher_sha256 = $sentinelHash
            output_path = $runtimeRelocatedOutput
            process_decoded = $relocatedRun.process_decoded
            has_run_key = $relocatedRun.has_run_key
            command_decoded = $relocatedRun.command_decoded
        }
    }
    sentinel = [ordered]@{
        sha256 = $sentinelHash
        expected_exit_code = 73
        expected_system_sid = 'S-1-5-18'
        expected_system_integrity_sid = 'S-1-16-16384'
    }
    pack_tree = [ordered]@{
        directories = @(
            'evidence',
            'evidence\no-whitelist',
            'evidence\relocated',
            'no-whitelist',
            'relocated-root',
            'signature-negative',
            'signed-input'
        )
        files = @($files)
    }
}
if ($EvidenceMode -ceq 'interactive-system-cmd') {
    $manifest.expected_requester['session_id'] = $ExpectedRequesterSessionId
    $manifest.sentinel['expected_schema_version'] = 3
    $manifest.sentinel['evidence_mode'] = $EvidenceMode
    $manifest.sentinel['interactive_cmd'] = $interactiveCmdBinding
    $manifest.sentinel['interactive_desktop'] = 'winsta0\default'
    $manifest.sentinel['interactive_lifetime'] = 'until-user-exit'
    $manifest.sentinel['interactive_timeout_milliseconds'] = $interactiveCmdTimeoutMilliseconds
    $manifest.sentinel['interactive_job_kill_on_close_required'] = $true
    $manifest.run.no_whitelist['interactive_system_cmd'] = $false
    $manifest.run.relocated['interactive_system_cmd'] = $true
}
$manifestPath = Join-Path $runRoot 'manifest.json'
$manifestBytes = [Text.UTF8Encoding]::new($false).GetBytes(($manifest | ConvertTo-Json -Depth 10))
Write-HostPackNewBytes $manifestPath $manifestBytes
$manifestHash = Get-HostPackSha256 $manifestBytes

$markerPath = Join-Path $runRoot 'marker.json'
$marker = [ordered]@{
    schema = if ($EvidenceMode -ceq 'interactive-system-cmd') {
        'steam-service-host-local-marker/v3'
    } else {
        'steam-service-host-local-marker/v2'
    }
    run_id = $RunId
    manifest_relative_path = 'manifest.json'
    manifest_length = $manifestBytes.Length
    manifest_sha256 = $manifestHash
    active_policy_sha256 = Get-HostPackSha256 $activePolicyBytes
    game_launch_permitted = $false
}
$markerBytes = [Text.UTF8Encoding]::new($false).GetBytes(($marker | ConvertTo-Json -Compress))
Write-HostPackNewBytes $markerPath $markerBytes

[pscustomobject]@{
    schema = if ($EvidenceMode -ceq 'interactive-system-cmd') {
        'steam-service-host-local-pack-result/v3'
    } else {
        'steam-service-host-local-pack-result/v2'
    }
    pack_root = $runRoot
    manifest_path = $manifestPath
    manifest_sha256 = $manifestHash
    marker_path = $markerPath
    marker_sha256 = Get-HostPackSha256 $markerBytes
    signed_vdf_sha256 = $signedHash
    negative_vdf_sha256 = Get-HostPackSha256 $negativeBytes
    sentinel_sha256 = $sentinelHash
    active_ipc_allowed = $true
    game_launch_permitted = $false
    evidence_mode = $EvidenceMode
}
