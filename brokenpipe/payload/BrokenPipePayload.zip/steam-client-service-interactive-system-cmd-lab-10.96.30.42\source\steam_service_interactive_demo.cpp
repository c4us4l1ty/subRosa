#include <windows.h>
#include <bcrypt.h>
#include <sddl.h>
#include <tlhelp32.h>

#include <cstdint>
#include <cstdio>
#include <string>
#include <vector>

namespace {

constexpr int kSuccessExitCode = 73;
constexpr DWORD kInteractiveWaitMilliseconds = INFINITE;
constexpr ULONG kObjCaseInsensitive = 0x00000040;
constexpr ULONG kObjDontReparse = 0x00001000;
constexpr ULONG kFileOpen = 1;
constexpr ULONG kFileCreate = 2;
constexpr ULONG kFileDirectoryFile = 0x00000001;
constexpr ULONG kFileWriteThrough = 0x00000002;
constexpr ULONG kFileSynchronousIoNonAlert = 0x00000020;
constexpr ULONG kFileNonDirectoryFile = 0x00000040;
constexpr ULONG kFileOpenReparsePoint = 0x00200000;

struct NtUnicodeString {
    USHORT length;
    USHORT maximum_length;
    PWSTR buffer;
};

struct NtObjectAttributes {
    ULONG length;
    HANDLE root_directory;
    NtUnicodeString* object_name;
    ULONG attributes;
    PVOID security_descriptor;
    PVOID security_quality_of_service;
};

struct NtIoStatusBlock {
    union {
        LONG status;
        PVOID pointer;
    } value;
    ULONG_PTR information;
};

using NtCreateFileFunction = LONG(NTAPI*)(
    PHANDLE,
    ACCESS_MASK,
    NtObjectAttributes*,
    NtIoStatusBlock*,
    PLARGE_INTEGER,
    ULONG,
    ULONG,
    ULONG,
    ULONG,
    PVOID,
    ULONG
);

using RtlNtStatusToDosErrorFunction = ULONG(NTAPI*)(LONG);

class ScopedHandle {
public:
    explicit ScopedHandle(HANDLE handle = INVALID_HANDLE_VALUE) : handle_(handle) {}
    ~ScopedHandle() { Reset(); }
    ScopedHandle(const ScopedHandle&) = delete;
    ScopedHandle& operator=(const ScopedHandle&) = delete;

    HANDLE Get() const { return handle_; }
    void Reset(HANDLE handle = INVALID_HANDLE_VALUE) {
        if (handle_ != nullptr && handle_ != INVALID_HANDLE_VALUE) {
            CloseHandle(handle_);
        }
        handle_ = handle;
    }
    HANDLE Release() {
        const HANDLE handle = handle_;
        handle_ = INVALID_HANDLE_VALUE;
        return handle;
    }

private:
    HANDLE handle_;
};

std::wstring GetLastErrorText(DWORD error) {
    LPWSTR buffer = nullptr;
    const DWORD length = FormatMessageW(
        FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
        nullptr,
        error,
        0,
        reinterpret_cast<LPWSTR>(&buffer),
        0,
        nullptr
    );
    std::wstring result = length == 0 ? L"unknown error" : std::wstring(buffer, length);
    if (buffer != nullptr) {
        LocalFree(buffer);
    }
    return result;
}

bool GetRequiredArguments(
    int argc,
    wchar_t* argv[],
    std::wstring* run_directory,
    std::wstring* output
) {
    if (argc != 5 || wcscmp(argv[1], L"--run-dir") != 0 ||
        wcscmp(argv[3], L"--output") != 0) {
        return false;
    }
    *run_directory = argv[2];
    *output = argv[4];
    return !run_directory->empty() && !output->empty();
}

#ifdef STEAM_SERVICE_INTERACTIVE_DEMO
bool ParseDecimalDword(const wchar_t* value, DWORD* result) {
    if (value == nullptr || *value == L'\0') {
        return false;
    }
    uint64_t parsed = 0;
    for (const wchar_t* current = value; *current != L'\0'; ++current) {
        if (*current < L'0' || *current > L'9') {
            return false;
        }
        parsed = parsed * 10 + static_cast<uint64_t>(*current - L'0');
        if (parsed > MAXDWORD) {
            return false;
        }
    }
    *result = static_cast<DWORD>(parsed);
    return true;
}

bool GetInteractiveDemoArguments(
    int argc,
    wchar_t* argv[],
    std::wstring* run_directory,
    std::wstring* output,
    DWORD* requester_session_id
) {
    if (argc != 8 || wcscmp(argv[1], L"--run-dir") != 0 ||
        wcscmp(argv[3], L"--output") != 0 ||
        wcscmp(argv[5], L"--interactive-system-cmd") != 0 ||
        wcscmp(argv[6], L"--expected-session-id") != 0) {
        return false;
    }
    *run_directory = argv[2];
    *output = argv[4];
    return !run_directory->empty() && !output->empty() &&
        ParseDecimalDword(argv[7], requester_session_id) && *requester_session_id != 0;
}
#endif

bool NormalizeAbsoluteLocalPath(const std::wstring& path, std::wstring* normalized) {
    const bool drive_letter = path.size() >= 3 &&
        ((path[0] >= L'A' && path[0] <= L'Z') || (path[0] >= L'a' && path[0] <= L'z'));
    if (!drive_letter || path[1] != L':' || path[2] != L'\\' ||
        path.find(L'/') != std::wstring::npos) {
        return false;
    }
    if (path.rfind(L"\\\\", 0) == 0 || path.find(L':', 2) != std::wstring::npos) {
        return false;
    }

    wchar_t full_path[MAX_PATH]{};
    const DWORD length = GetFullPathNameW(path.c_str(), ARRAYSIZE(full_path), full_path, nullptr);
    if (length == 0 || length >= ARRAYSIZE(full_path) || path != full_path) {
        return false;
    }
    normalized->assign(full_path, length);
    return true;
}

DWORD NtStatusToDosError(LONG status) {
    const HMODULE ntdll = GetModuleHandleW(L"ntdll.dll");
    if (ntdll == nullptr) {
        return ERROR_GEN_FAILURE;
    }
    const auto convert = reinterpret_cast<RtlNtStatusToDosErrorFunction>(
        GetProcAddress(ntdll, "RtlNtStatusToDosError")
    );
    return convert == nullptr ? ERROR_GEN_FAILURE : convert(status);
}

bool NtOpenRelative(
    HANDLE root,
    const std::wstring& name,
    ACCESS_MASK access,
    ULONG disposition,
    ULONG options,
    ULONG attributes,
    ULONG share,
    HANDLE* result
) {
    if (name.empty() || name == L"." || name == L".." ||
        name.find(L'\\') != std::wstring::npos ||
        name.size() > (USHRT_MAX / sizeof(wchar_t)) - 1) {
        return false;
    }
    const HMODULE ntdll = GetModuleHandleW(L"ntdll.dll");
    if (ntdll == nullptr) {
        SetLastError(ERROR_PROC_NOT_FOUND);
        return false;
    }
    const auto create_file = reinterpret_cast<NtCreateFileFunction>(
        GetProcAddress(ntdll, "NtCreateFile")
    );
    if (create_file == nullptr) {
        SetLastError(ERROR_PROC_NOT_FOUND);
        return false;
    }

    NtUnicodeString object_name{};
    object_name.length = static_cast<USHORT>(name.size() * sizeof(wchar_t));
    object_name.maximum_length = static_cast<USHORT>(object_name.length + sizeof(wchar_t));
    object_name.buffer = const_cast<PWSTR>(name.c_str());
    NtObjectAttributes object_attributes{};
    object_attributes.length = sizeof(object_attributes);
    object_attributes.root_directory = root;
    object_attributes.object_name = &object_name;
    object_attributes.attributes = kObjCaseInsensitive | kObjDontReparse;
    NtIoStatusBlock io_status{};
    HANDLE handle = INVALID_HANDLE_VALUE;
    const LONG status = create_file(
        &handle,
        access,
        &object_attributes,
        &io_status,
        nullptr,
        attributes,
        share,
        disposition,
        options,
        nullptr,
        0
    );
    if (status < 0) {
        SetLastError(NtStatusToDosError(status));
        return false;
    }
    *result = handle;
    return true;
}

bool IsOrdinaryDirectory(HANDLE handle) {
    BY_HANDLE_FILE_INFORMATION information{};
    return GetFileInformationByHandle(handle, &information) != FALSE &&
        (information.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) != 0 &&
        (information.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT) == 0;
}

bool OpenRunDirectoryNoReparse(const std::wstring& path, HANDLE* result) {
    if (path.size() <= 3 || path.back() == L'\\') {
        return false;
    }
    const std::wstring root_path = path.substr(0, 3);
    if (GetDriveTypeW(root_path.c_str()) != DRIVE_FIXED) {
        SetLastError(ERROR_INVALID_DRIVE);
        return false;
    }
    ScopedHandle current(CreateFileW(
        root_path.c_str(),
        FILE_LIST_DIRECTORY | FILE_TRAVERSE | FILE_READ_ATTRIBUTES | SYNCHRONIZE,
        FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
        nullptr,
        OPEN_EXISTING,
        FILE_FLAG_BACKUP_SEMANTICS | FILE_FLAG_OPEN_REPARSE_POINT,
        nullptr
    ));
    if (current.Get() == INVALID_HANDLE_VALUE || !IsOrdinaryDirectory(current.Get())) {
        return false;
    }

    size_t start = 3;
    while (start < path.size()) {
        const size_t end = path.find(L'\\', start);
        const size_t length = (end == std::wstring::npos ? path.size() : end) - start;
        if (length == 0) {
            return false;
        }
        HANDLE next = INVALID_HANDLE_VALUE;
        if (!NtOpenRelative(
            current.Get(),
            path.substr(start, length),
            FILE_LIST_DIRECTORY | FILE_TRAVERSE | FILE_READ_ATTRIBUTES | SYNCHRONIZE,
            kFileOpen,
            kFileDirectoryFile | kFileSynchronousIoNonAlert | kFileOpenReparsePoint,
            FILE_ATTRIBUTE_NORMAL,
            FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
            &next
        )) {
            return false;
        }
        current.Reset(next);
        if (!IsOrdinaryDirectory(current.Get())) {
            return false;
        }
        if (end == std::wstring::npos) {
            break;
        }
        start = end + 1;
    }
    *result = current.Release();
    return true;
}

bool ResolveOutputPaths(
    const std::wstring& run_directory_argument,
    const std::wstring& output_argument,
    std::wstring* run_directory,
    std::wstring* output
) {
    if (!NormalizeAbsoluteLocalPath(run_directory_argument, run_directory) ||
        !NormalizeAbsoluteLocalPath(output_argument, output)) {
        return false;
    }
    const std::wstring expected_output = *run_directory + L"\\sentinel.json";
    return _wcsicmp(expected_output.c_str(), output->c_str()) == 0;
}

std::wstring JsonEscape(const std::wstring& value) {
    std::wstring escaped;
    escaped.reserve(value.size() + 16);
    for (const wchar_t character : value) {
        switch (character) {
            case L'\\': escaped += L"\\\\"; break;
            case L'\"': escaped += L"\\\""; break;
            case L'\b': escaped += L"\\b"; break;
            case L'\f': escaped += L"\\f"; break;
            case L'\n': escaped += L"\\n"; break;
            case L'\r': escaped += L"\\r"; break;
            case L'\t': escaped += L"\\t"; break;
            default:
                if (character < 0x20) {
                    wchar_t buffer[7]{};
                    swprintf_s(buffer, L"\\u%04x", static_cast<unsigned int>(character));
                    escaped += buffer;
                } else {
                    escaped += character;
                }
                break;
        }
    }
    return escaped;
}

std::string Utf8(const std::wstring& value) {
    if (value.empty()) {
        return {};
    }
    const int required = WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, value.c_str(),
        static_cast<int>(value.size()), nullptr, 0, nullptr, nullptr);
    if (required == 0) {
        return {};
    }
    std::string result(static_cast<size_t>(required), '\0');
    if (WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, value.c_str(),
        static_cast<int>(value.size()), result.data(), required, nullptr, nullptr) == 0) {
        return {};
    }
    return result;
}

bool GetSidString(PSID sid, std::wstring* result) {
    LPWSTR converted = nullptr;
    if (!ConvertSidToStringSidW(sid, &converted)) {
        return false;
    }
    *result = converted;
    LocalFree(converted);
    return true;
}

bool GetAccountName(PSID sid, std::wstring* result) {
    DWORD account_length = 0;
    DWORD domain_length = 0;
    SID_NAME_USE sid_type{};
    LookupAccountSidW(nullptr, sid, nullptr, &account_length, nullptr, &domain_length, &sid_type);
    if (GetLastError() != ERROR_INSUFFICIENT_BUFFER || account_length == 0) {
        return false;
    }

    std::vector<wchar_t> account(account_length);
    std::vector<wchar_t> domain(domain_length == 0 ? 1 : domain_length);
    if (!LookupAccountSidW(nullptr, sid, account.data(), &account_length, domain.data(),
        &domain_length, &sid_type)) {
        return false;
    }
    *result = domain_length == 0
        ? std::wstring(account.data())
        : std::wstring(domain.data()) + L"\\" + account.data();
    return true;
}

bool GetCurrentToken(HANDLE* token) {
    return OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, token) != FALSE;
}

bool GetTokenInformationBuffer(HANDLE token, TOKEN_INFORMATION_CLASS kind, std::vector<BYTE>* buffer) {
    DWORD length = 0;
    GetTokenInformation(token, kind, nullptr, 0, &length);
    if (GetLastError() != ERROR_INSUFFICIENT_BUFFER || length == 0) {
        return false;
    }
    buffer->resize(length);
    return GetTokenInformation(token, kind, buffer->data(), length, &length) != FALSE;
}

bool GetTokenDetails(
    HANDLE token,
    std::wstring* sid,
    std::wstring* identity,
    DWORD* elevation_type,
    std::wstring* integrity_sid,
    DWORD* integrity_rid,
    DWORD* session_id
) {
    std::vector<BYTE> user_buffer;
    std::vector<BYTE> integrity_buffer;
    if (!GetTokenInformationBuffer(token, TokenUser, &user_buffer) ||
        !GetTokenInformationBuffer(token, TokenIntegrityLevel, &integrity_buffer)) {
        return false;
    }

    const auto* user = reinterpret_cast<const TOKEN_USER*>(user_buffer.data());
    const auto* integrity = reinterpret_cast<const TOKEN_MANDATORY_LABEL*>(integrity_buffer.data());
    if (!GetSidString(user->User.Sid, sid) || !GetAccountName(user->User.Sid, identity) ||
        !GetSidString(integrity->Label.Sid, integrity_sid)) {
        return false;
    }

    const PUCHAR count = GetSidSubAuthorityCount(integrity->Label.Sid);
    if (count == nullptr || *count == 0) {
        return false;
    }
    const PDWORD authority = GetSidSubAuthority(integrity->Label.Sid, *count - 1);
    if (authority == nullptr) {
        return false;
    }
    *integrity_rid = *authority;

    DWORD length = 0;
    if (!GetTokenInformation(token, TokenElevationType, elevation_type, sizeof(*elevation_type), &length) ||
        !GetTokenInformation(token, TokenSessionId, session_id, sizeof(*session_id), &length)) {
        return false;
    }
    return true;
}

bool GetSelfPath(std::wstring* path) {
    DWORD capacity = MAX_PATH;
    while (capacity <= 32768) {
        std::vector<wchar_t> buffer(capacity);
        const DWORD length = GetModuleFileNameW(nullptr, buffer.data(), capacity);
        if (length == 0) {
            return false;
        }
        if (length < capacity - 1) {
            path->assign(buffer.data(), length);
            return true;
        }
        capacity *= 2;
    }
    return false;
}

bool GetParent(DWORD* parent_pid, std::wstring* parent_image) {
    const DWORD self_pid = GetCurrentProcessId();
    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snapshot == INVALID_HANDLE_VALUE) {
        return false;
    }

    PROCESSENTRY32W entry{};
    entry.dwSize = sizeof(entry);
    bool found = false;
    if (Process32FirstW(snapshot, &entry)) {
        do {
            if (entry.th32ProcessID == self_pid) {
                *parent_pid = entry.th32ParentProcessID;
                found = true;
                break;
            }
        } while (Process32NextW(snapshot, &entry));
    }
    CloseHandle(snapshot);
    if (!found) {
        return false;
    }

    HANDLE parent = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, *parent_pid);
    if (parent == nullptr) {
        *parent_image = L"";
        return true;
    }
    DWORD capacity = 32768;
    std::vector<wchar_t> image(capacity);
    if (QueryFullProcessImageNameW(parent, 0, image.data(), &capacity)) {
        parent_image->assign(image.data(), capacity);
    } else {
        *parent_image = L"";
    }
    CloseHandle(parent);
    return true;
}

std::wstring Hex(const std::vector<BYTE>& bytes) {
    static constexpr wchar_t kDigits[] = L"0123456789abcdef";
    std::wstring result;
    result.reserve(bytes.size() * 2);
    for (const BYTE value : bytes) {
        result += kDigits[(value >> 4) & 0x0f];
        result += kDigits[value & 0x0f];
    }
    return result;
}

bool HashFileSha256(const std::wstring& path, std::wstring* digest) {
    HANDLE file = CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL, nullptr);
    if (file == INVALID_HANDLE_VALUE) {
        return false;
    }

    BCRYPT_ALG_HANDLE algorithm = nullptr;
    BCRYPT_HASH_HANDLE hash = nullptr;
    std::vector<BYTE> object;
    std::vector<BYTE> output(32);
    bool success = false;
    do {
        if (BCryptOpenAlgorithmProvider(&algorithm, BCRYPT_SHA256_ALGORITHM, nullptr, 0) != 0) {
            break;
        }
        DWORD object_length = 0;
        DWORD result_length = 0;
        if (BCryptGetProperty(algorithm, BCRYPT_OBJECT_LENGTH,
            reinterpret_cast<PUCHAR>(&object_length), sizeof(object_length), &result_length, 0) != 0) {
            break;
        }
        object.resize(object_length);
        if (BCryptCreateHash(algorithm, &hash, object.data(), object_length, nullptr, 0, 0) != 0) {
            break;
        }
        std::vector<BYTE> buffer(64 * 1024);
        for (;;) {
            DWORD bytes_read = 0;
            if (!ReadFile(file, buffer.data(), static_cast<DWORD>(buffer.size()), &bytes_read, nullptr)) {
                break;
            }
            if (bytes_read == 0) {
                if (BCryptFinishHash(hash, output.data(), static_cast<ULONG>(output.size()), 0) == 0) {
                    *digest = Hex(output);
                    success = true;
                }
                break;
            }
            if (BCryptHashData(hash, buffer.data(), bytes_read, 0) != 0) {
                break;
            }
        }
    } while (false);

    if (hash != nullptr) {
        BCryptDestroyHash(hash);
    }
    if (algorithm != nullptr) {
        BCryptCloseAlgorithmProvider(algorithm, 0);
    }
    CloseHandle(file);
    return success;
}

std::wstring UtcTimestamp() {
    FILETIME file_time{};
    GetSystemTimeAsFileTime(&file_time);
    SYSTEMTIME system_time{};
    FileTimeToSystemTime(&file_time, &system_time);
    wchar_t buffer[40]{};
    swprintf_s(buffer, L"%04u-%02u-%02uT%02u:%02u:%02u.%03uZ",
        system_time.wYear, system_time.wMonth, system_time.wDay, system_time.wHour,
        system_time.wMinute, system_time.wSecond, system_time.wMilliseconds);
    return buffer;
}

bool OpenNewOutputFile(HANDLE run_directory, HANDLE* raw_file) {
    if (!NtOpenRelative(
        run_directory,
        L"sentinel.json",
        GENERIC_WRITE | SYNCHRONIZE,
        kFileCreate,
        kFileWriteThrough | kFileSynchronousIoNonAlert | kFileNonDirectoryFile |
            kFileOpenReparsePoint,
        FILE_ATTRIBUTE_NORMAL,
        0,
        raw_file
    )) {
        return false;
    }
    return true;
}

bool WriteOpenOutputFile(HANDLE file, const std::string& json) {
    DWORD written = 0;
    const bool success = json.size() <= MAXDWORD &&
        WriteFile(file, json.data(), static_cast<DWORD>(json.size()), &written, nullptr) != FALSE &&
        written == json.size() && FlushFileBuffers(file) != FALSE;
    const DWORD error = success ? ERROR_SUCCESS :
        (GetLastError() == ERROR_SUCCESS ? ERROR_WRITE_FAULT : GetLastError());
    SetLastError(error);
    return success;
}

bool WriteNewFile(HANDLE run_directory, const std::string& json) {
    HANDLE raw_file = INVALID_HANDLE_VALUE;
    if (!OpenNewOutputFile(run_directory, &raw_file)) {
        return false;
    }
    ScopedHandle file(raw_file);
    return WriteOpenOutputFile(file.Get(), json);
}

#ifdef STEAM_SERVICE_INTERACTIVE_DEMO
bool GetSystemCmdPath(std::wstring* result) {
    std::vector<wchar_t> buffer(MAX_PATH);
    for (;;) {
        const UINT length = GetSystemDirectoryW(buffer.data(), static_cast<UINT>(buffer.size()));
        if (length == 0) {
            return false;
        }
        if (length < buffer.size()) {
            *result = std::wstring(buffer.data(), length) + L"\\cmd.exe";
            const DWORD attributes = GetFileAttributesW(result->c_str());
            return attributes != INVALID_FILE_ATTRIBUTES &&
                (attributes & FILE_ATTRIBUTE_DIRECTORY) == 0;
        }
        if (buffer.size() >= 32768) {
            SetLastError(ERROR_FILENAME_EXCED_RANGE);
            return false;
        }
        buffer.resize(static_cast<size_t>(length) + 1);
    }
}

bool GetTokenDetailsForProcess(
    HANDLE process,
    std::wstring* sid,
    std::wstring* identity,
    DWORD* elevation_type,
    std::wstring* integrity_sid,
    DWORD* integrity_rid,
    DWORD* session_id
) {
    HANDLE raw_token = nullptr;
    if (!OpenProcessToken(process, TOKEN_QUERY, &raw_token)) {
        return false;
    }
    ScopedHandle token(raw_token);
    return GetTokenDetails(token.Get(), sid, identity, elevation_type, integrity_sid, integrity_rid, session_id);
}

bool IsExpectedSystemToken(const std::wstring& sid, const std::wstring& integrity_sid,
    DWORD session_id, DWORD requester_session_id) {
    return sid == L"S-1-5-18" && integrity_sid == L"S-1-16-16384" &&
        session_id == requester_session_id;
}

bool TerminateChildAndConfirm(HANDLE process, UINT exit_code) {
    DWORD current_exit_code = 0;
    if (GetExitCodeProcess(process, &current_exit_code) && current_exit_code != STILL_ACTIVE) {
        return true;
    }
    if (!TerminateProcess(process, exit_code)) {
        return GetExitCodeProcess(process, &current_exit_code) && current_exit_code != STILL_ACTIVE;
    }
    return WaitForSingleObject(process, 5000) == WAIT_OBJECT_0;
}

bool CreateKillOnCloseJob(HANDLE* result) {
    const HANDLE job = CreateJobObjectW(nullptr, nullptr);
    if (job == nullptr) {
        return false;
    }
    JOBOBJECT_EXTENDED_LIMIT_INFORMATION limits{};
    limits.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
    if (!SetInformationJobObject(job, JobObjectExtendedLimitInformation, &limits, sizeof(limits))) {
        const DWORD error = GetLastError();
        CloseHandle(job);
        SetLastError(error);
        return false;
    }
    *result = job;
    return true;
}

bool TerminateJobAndConfirm(HANDLE job, UINT exit_code) {
    if (!TerminateJobObject(job, exit_code)) {
        return false;
    }
    const ULONGLONG deadline = GetTickCount64() + 5000;
    for (;;) {
        JOBOBJECT_BASIC_ACCOUNTING_INFORMATION accounting{};
        if (!QueryInformationJobObject(
            job,
            JobObjectBasicAccountingInformation,
            &accounting,
            sizeof(accounting),
            nullptr
        )) {
            return false;
        }
        if (accounting.ActiveProcesses == 0) {
            return true;
        }
        if (GetTickCount64() >= deadline) {
            return false;
        }
        Sleep(10);
    }
}

int InteractiveDemoMain(int argc, wchar_t* argv[]) {
    std::wstring run_directory_argument;
    std::wstring output_argument;
    std::wstring run_directory;
    std::wstring output_path;
    DWORD requester_session_id = 0;
    if (!GetInteractiveDemoArguments(argc, argv, &run_directory_argument, &output_argument,
        &requester_session_id) ||
        !ResolveOutputPaths(run_directory_argument, output_argument, &run_directory, &output_path)) {
        fwprintf(stderr, L"usage: %ls --run-dir <existing non-reparse directory> "
            L"--output <run-dir>\\sentinel.json --interactive-system-cmd "
            L"--expected-session-id <decimal>\n", argv[0]);
        return ERROR_INVALID_PARAMETER;
    }

    HANDLE raw_run_directory = INVALID_HANDLE_VALUE;
    if (!OpenRunDirectoryNoReparse(run_directory, &raw_run_directory)) {
        fwprintf(stderr, L"run directory open failed: %ls\n", GetLastErrorText(GetLastError()).c_str());
        return ERROR_INVALID_PARAMETER;
    }
    ScopedHandle run_directory_handle(raw_run_directory);

    std::wstring self_path;
    std::wstring self_hash;
    if (!GetSelfPath(&self_path) || !HashFileSha256(self_path, &self_hash)) {
        fwprintf(stderr, L"self inspection failed: %ls\n", GetLastErrorText(GetLastError()).c_str());
        return ERROR_READ_FAULT;
    }

    std::wstring helper_sid;
    std::wstring helper_identity;
    std::wstring helper_integrity_sid;
    DWORD helper_elevation_type = 0;
    DWORD helper_integrity_rid = 0;
    DWORD helper_session_id = 0;
    if (!GetTokenDetailsForProcess(GetCurrentProcess(), &helper_sid, &helper_identity,
        &helper_elevation_type, &helper_integrity_sid, &helper_integrity_rid, &helper_session_id) ||
        !IsExpectedSystemToken(helper_sid, helper_integrity_sid, helper_session_id,
            requester_session_id)) {
        fwprintf(stderr, L"helper token or session did not match the required SYSTEM interactive token\n");
        return ERROR_ACCESS_DENIED;
    }

    std::wstring cmd_path;
    if (!GetSystemCmdPath(&cmd_path)) {
        fwprintf(stderr, L"System32 cmd.exe resolution failed: %ls\n", GetLastErrorText(GetLastError()).c_str());
        return ERROR_FILE_NOT_FOUND;
    }
    std::wstring cmd_hash;
    if (!HashFileSha256(cmd_path, &cmd_hash)) {
        fwprintf(stderr, L"System32 cmd.exe hashing failed: %ls\n", GetLastErrorText(GetLastError()).c_str());
        return ERROR_READ_FAULT;
    }
    const size_t separator = cmd_path.find_last_of(L'\\');
    if (separator == std::wstring::npos) {
        return ERROR_INVALID_NAME;
    }
    const std::wstring cmd_directory = cmd_path.substr(0, separator);
    const std::wstring fixed_command_line = L"\"" + cmd_path + L"\" /D /Q";
    std::vector<wchar_t> command_line(fixed_command_line.begin(), fixed_command_line.end());
    command_line.push_back(L'\0');
    HANDLE raw_child_job = nullptr;
    if (!CreateKillOnCloseJob(&raw_child_job)) {
        fwprintf(stderr, L"child job creation failed: %ls\n", GetLastErrorText(GetLastError()).c_str());
        return ERROR_GEN_FAILURE;
    }
    ScopedHandle child_job(raw_child_job);
    STARTUPINFOW startup{};
    startup.cb = sizeof(startup);
    wchar_t interactive_desktop[] = L"winsta0\\default";
    startup.lpDesktop = interactive_desktop;
    PROCESS_INFORMATION child{};
    if (!CreateProcessW(cmd_path.c_str(), command_line.data(), nullptr, nullptr, FALSE,
        CREATE_NEW_CONSOLE | CREATE_SUSPENDED, nullptr, cmd_directory.c_str(), &startup, &child)) {
        fwprintf(stderr, L"cmd.exe creation failed: %ls\n", GetLastErrorText(GetLastError()).c_str());
        return ERROR_GEN_FAILURE;
    }
    ScopedHandle child_process(child.hProcess);
    ScopedHandle child_thread(child.hThread);

    std::wstring child_sid;
    std::wstring child_identity;
    std::wstring child_integrity_sid;
    DWORD child_elevation_type = 0;
    DWORD child_integrity_rid = 0;
    DWORD child_session_id = 0;
    if (!GetTokenDetailsForProcess(child_process.Get(), &child_sid, &child_identity,
        &child_elevation_type, &child_integrity_sid, &child_integrity_rid, &child_session_id) ||
        !IsExpectedSystemToken(child_sid, child_integrity_sid, child_session_id,
            requester_session_id)) {
        const bool terminated = TerminateChildAndConfirm(child_process.Get(), ERROR_ACCESS_DENIED);
        fwprintf(stderr, L"suspended child token or session did not match the required SYSTEM interactive token\n");
        return terminated ? ERROR_ACCESS_DENIED : ERROR_PROCESS_ABORTED;
    }

    DWORD parent_pid = 0;
    std::wstring parent_image;
    if (!GetParent(&parent_pid, &parent_image)) {
        const bool terminated = TerminateChildAndConfirm(child_process.Get(), ERROR_READ_FAULT);
        fwprintf(stderr, L"parent inspection failed: %ls\n", GetLastErrorText(GetLastError()).c_str());
        return terminated ? ERROR_READ_FAULT : ERROR_PROCESS_ABORTED;
    }

    if (!AssignProcessToJobObject(child_job.Get(), child_process.Get())) {
        const DWORD assignment_error = GetLastError();
        const bool terminated = TerminateChildAndConfirm(child_process.Get(), ERROR_GEN_FAILURE);
        fwprintf(stderr, L"child job assignment failed: %ls\n",
            GetLastErrorText(assignment_error).c_str());
        return terminated ? ERROR_GEN_FAILURE : ERROR_PROCESS_ABORTED;
    }
    if (ResumeThread(child_thread.Get()) == static_cast<DWORD>(-1)) {
        const bool terminated = TerminateJobAndConfirm(child_job.Get(), ERROR_GEN_FAILURE);
        fwprintf(stderr, L"child resume failed: %ls\n", GetLastErrorText(GetLastError()).c_str());
        return terminated ? ERROR_GEN_FAILURE : ERROR_PROCESS_ABORTED;
    }

    bool child_cleanup_confirmed = false;
    DWORD child_exit_code = STILL_ACTIVE;
    const DWORD wait_result = WaitForSingleObject(child_process.Get(), kInteractiveWaitMilliseconds);
    if (wait_result != WAIT_OBJECT_0) {
        const DWORD wait_error = GetLastError();
        const bool terminated = TerminateJobAndConfirm(child_job.Get(), ERROR_GEN_FAILURE);
        fwprintf(stderr, L"interactive child wait failed: %ls\n", GetLastErrorText(wait_error).c_str());
        return terminated ? ERROR_GEN_FAILURE : ERROR_PROCESS_ABORTED;
    }
    if (!GetExitCodeProcess(child_process.Get(), &child_exit_code) ||
        child_exit_code == STILL_ACTIVE) {
        const bool terminated = TerminateJobAndConfirm(child_job.Get(), ERROR_GEN_FAILURE);
        fwprintf(stderr, L"interactive child exit verification failed\n");
        return terminated ? ERROR_READ_FAULT : ERROR_PROCESS_ABORTED;
    }
    child_cleanup_confirmed = TerminateJobAndConfirm(child_job.Get(), ERROR_PROCESS_ABORTED);
    if (!child_cleanup_confirmed) {
        fwprintf(stderr, L"interactive child tree cleanup failed\n");
        return ERROR_PROCESS_ABORTED;
    }
    if (!GetExitCodeProcess(child_process.Get(), &child_exit_code) || child_exit_code == STILL_ACTIVE) {
        fwprintf(stderr, L"interactive child exit verification failed\n");
        return ERROR_READ_FAULT;
    }

    const DWORD child_creation_flags = CREATE_NEW_CONSOLE | CREATE_SUSPENDED;
    const std::wstring json =
        L"{\n"
        L"  \"schema_version\": 3,\n"
        L"  \"evidence_mode\": \"interactive-system-cmd\",\n"
        L"  \"interactive_cmd_spawned\": true,\n"
        L"  \"timestamp_utc\": \"" + JsonEscape(UtcTimestamp()) + L"\",\n"
        L"  \"run_directory\": \"" + JsonEscape(run_directory) + L"\",\n"
        L"  \"output_path\": \"" + JsonEscape(output_path) + L"\",\n"
        L"  \"requester_session_id\": " + std::to_wstring(requester_session_id) + L",\n"
        L"  \"user_sid\": \"" + JsonEscape(helper_sid) + L"\",\n"
        L"  \"identity\": \"" + JsonEscape(helper_identity) + L"\",\n"
        L"  \"token_elevation_type\": " + std::to_wstring(helper_elevation_type) + L",\n"
        L"  \"integrity_sid\": \"" + JsonEscape(helper_integrity_sid) + L"\",\n"
        L"  \"integrity_rid\": " + std::to_wstring(helper_integrity_rid) + L",\n"
        L"  \"session_id\": " + std::to_wstring(helper_session_id) + L",\n"
        L"  \"process_id\": " + std::to_wstring(GetCurrentProcessId()) + L",\n"
        L"  \"parent_process_id\": " + std::to_wstring(parent_pid) + L",\n"
        L"  \"parent_image\": \"" + JsonEscape(parent_image) + L"\",\n"
        L"  \"self_path\": \"" + JsonEscape(self_path) + L"\",\n"
        L"  \"self_sha256\": \"" + JsonEscape(self_hash) + L"\",\n"
        L"  \"child_process_id\": " + std::to_wstring(child.dwProcessId) + L",\n"
        L"  \"child_user_sid\": \"" + JsonEscape(child_sid) + L"\",\n"
        L"  \"child_identity\": \"" + JsonEscape(child_identity) + L"\",\n"
        L"  \"child_integrity_sid\": \"" + JsonEscape(child_integrity_sid) + L"\",\n"
        L"  \"child_integrity_rid\": " + std::to_wstring(child_integrity_rid) + L",\n"
        L"  \"child_session_id\": " + std::to_wstring(child_session_id) + L",\n"
        L"  \"child_image_path\": \"" + JsonEscape(cmd_path) + L"\",\n"
        L"  \"child_image_sha256\": \"" + JsonEscape(cmd_hash) + L"\",\n"
        L"  \"child_command_line\": \"" + JsonEscape(fixed_command_line) + L"\",\n"
        L"  \"child_desktop\": \"winsta0\\\\default\",\n"
        L"  \"child_creation_flags\": " + std::to_wstring(child_creation_flags) + L",\n"
        L"  \"child_job_assigned\": true,\n"
        L"  \"child_job_kill_on_close\": true,\n"
        L"  \"child_exit_observed\": true,\n"
        L"  \"child_exit_code\": " + std::to_wstring(child_exit_code) + L",\n"
        L"  \"child_terminated_by_timeout\": false,\n"
        L"  \"child_cleanup_confirmed\": " +
            std::wstring(child_cleanup_confirmed ? L"true" : L"false") + L",\n"
        L"  \"lifetime_policy\": \"until-user-exit\",\n"
        L"  \"timeout_milliseconds\": 0\n"
        L"}\n";
    const std::string utf8 = Utf8(json);
    if (utf8.empty() || !WriteNewFile(run_directory_handle.Get(), utf8)) {
        fwprintf(stderr, L"output write failed: %ls\n", GetLastErrorText(GetLastError()).c_str());
        return ERROR_WRITE_FAULT;
    }
    return kSuccessExitCode;
}
#endif

}

int wmain(int argc, wchar_t* argv[]) {
#ifdef STEAM_SERVICE_INTERACTIVE_DEMO
    return InteractiveDemoMain(argc, argv);
#else
    std::wstring run_directory_argument;
    std::wstring output_argument;
    std::wstring run_directory;
    std::wstring output_path;
    if (!GetRequiredArguments(argc, argv, &run_directory_argument, &output_argument) ||
        !ResolveOutputPaths(run_directory_argument, output_argument, &run_directory, &output_path)) {
        fwprintf(stderr, L"usage: %ls --run-dir <existing non-reparse directory> "
            L"--output <run-dir>\\sentinel.json\n", argv[0]);
        return ERROR_INVALID_PARAMETER;
    }
    HANDLE raw_run_directory = INVALID_HANDLE_VALUE;
    if (!OpenRunDirectoryNoReparse(run_directory, &raw_run_directory)) {
        fwprintf(stderr, L"run directory open failed: %ls\n",
            GetLastErrorText(GetLastError()).c_str());
        return ERROR_INVALID_PARAMETER;
    }
    ScopedHandle run_directory_handle(raw_run_directory);

    std::wstring self_path;
    std::wstring self_hash;
    if (!GetSelfPath(&self_path) || !HashFileSha256(self_path, &self_hash)) {
        fwprintf(stderr, L"self inspection failed: %ls\n", GetLastErrorText(GetLastError()).c_str());
        return ERROR_READ_FAULT;
    }

    HANDLE token = nullptr;
    std::wstring user_sid;
    std::wstring identity;
    std::wstring integrity_sid;
    DWORD elevation_type = 0;
    DWORD integrity_rid = 0;
    DWORD session_id = 0;
    if (!GetCurrentToken(&token) || !GetTokenDetails(token, &user_sid, &identity, &elevation_type,
        &integrity_sid, &integrity_rid, &session_id)) {
        if (token != nullptr) {
            CloseHandle(token);
        }
        fwprintf(stderr, L"token inspection failed: %ls\n", GetLastErrorText(GetLastError()).c_str());
        return ERROR_READ_FAULT;
    }
    CloseHandle(token);

    DWORD parent_pid = 0;
    std::wstring parent_image;
    if (!GetParent(&parent_pid, &parent_image)) {
        fwprintf(stderr, L"parent inspection failed: %ls\n", GetLastErrorText(GetLastError()).c_str());
        return ERROR_READ_FAULT;
    }

    const DWORD pid = GetCurrentProcessId();
    const std::wstring json =
        L"{\n"
        L"  \"schema_version\": 2,\n"
        L"  \"timestamp_utc\": \"" + JsonEscape(UtcTimestamp()) + L"\",\n"
        L"  \"run_directory\": \"" + JsonEscape(run_directory) + L"\",\n"
        L"  \"output_path\": \"" + JsonEscape(output_path) + L"\",\n"
        L"  \"user_sid\": \"" + JsonEscape(user_sid) + L"\",\n"
        L"  \"identity\": \"" + JsonEscape(identity) + L"\",\n"
        L"  \"token_elevation_type\": " + std::to_wstring(elevation_type) + L",\n"
        L"  \"integrity_sid\": \"" + JsonEscape(integrity_sid) + L"\",\n"
        L"  \"integrity_rid\": " + std::to_wstring(integrity_rid) + L",\n"
        L"  \"session_id\": " + std::to_wstring(session_id) + L",\n"
        L"  \"process_id\": " + std::to_wstring(pid) + L",\n"
        L"  \"parent_process_id\": " + std::to_wstring(parent_pid) + L",\n"
        L"  \"parent_image\": \"" + JsonEscape(parent_image) + L"\",\n"
        L"  \"self_path\": \"" + JsonEscape(self_path) + L"\",\n"
        L"  \"self_sha256\": \"" + JsonEscape(self_hash) + L"\"\n"
        L"}\n";
    const std::string utf8 = Utf8(json);
    if (utf8.empty() || !WriteNewFile(run_directory_handle.Get(), utf8)) {
        fwprintf(stderr, L"output write failed: %ls\n", GetLastErrorText(GetLastError()).c_str());
        return ERROR_WRITE_FAULT;
    }
    return kSuccessExitCode;
#endif
}
