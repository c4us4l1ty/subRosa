[CmdletBinding()]
param(
    [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$ManifestPath,
    [ValidateRange(500, 10000)][int]$TimeoutMilliseconds = 5000,
    [ValidateRange(1000, 30000)][int]$RunObservationMilliseconds = 10000,
    [ValidatePattern('^[0-9A-Fa-f]{64}$')][string]$ExpectedManifestSha256,
    [ValidatePattern('^[0-9A-Fa-f]{64}$')][string]$ExpectedMarkerSha256,
    [ValidatePattern('^[0-9A-Fa-f]{64}$')][string]$ExpectedControllerSha256,
    [ValidatePattern('^[0-9A-Fa-f]{64}$')][string]$ExpectedFrameModuleSha256,
    [switch]$Active,
    [switch]$AcknowledgeHostLocalRisk
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Get-HostControlSha256 {
    param([Parameter(Mandatory)][string]$Path)
    (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToUpperInvariant()
}

function Get-HostControlBytesSha256 {
    param([Parameter(Mandatory)][AllowEmptyCollection()][byte[]]$Bytes)
    $sha = [Security.Cryptography.SHA256]::Create()
    try { ([BitConverter]::ToString($sha.ComputeHash($Bytes))).Replace('-', '') }
    finally { $sha.Dispose() }
}

function Get-HostControlFixedPath {
    param([Parameter(Mandatory)][string]$Path)
    if ($Path -notmatch '^[A-Za-z]:\\' -or $Path.Contains('/') -or $Path.IndexOf(':', 2) -ge 0) {
        throw "Path must use a local drive-letter form: $Path"
    }
    $full = [IO.Path]::GetFullPath($Path)
    $drive = [IO.Path]::GetPathRoot($full)
    if ([IO.DriveInfo]::new($drive).DriveType -ne [IO.DriveType]::Fixed) {
        throw "Path must be on a fixed local volume: $Path"
    }
    $full
}

function Test-HostControlContained {
    param([string]$Root, [string]$Candidate)
    $rootFull = (Get-HostControlFixedPath $Root).TrimEnd('\')
    $candidateFull = Get-HostControlFixedPath $Candidate
    $candidateFull -ieq $rootFull -or $candidateFull.StartsWith(
        $rootFull + '\',
        [StringComparison]::OrdinalIgnoreCase
    )
}

function Assert-HostControlNoReparse {
    param(
        [Parameter(Mandatory)][string]$Path,
        [switch]$AllowMissingLeaf
    )
    $full = Get-HostControlFixedPath $Path
    $drive = [IO.Path]::GetPathRoot($full)
    $relative = $full.Substring($drive.Length)
    $parts = @($relative.Split('\', [StringSplitOptions]::RemoveEmptyEntries))
    $current = $drive
    for ($index = 0; $index -lt $parts.Count; $index++) {
        $current = Join-Path $current $parts[$index]
        if (-not (Test-Path -LiteralPath $current)) {
            if ($AllowMissingLeaf -and $index -eq $parts.Count - 1) { return $full }
            throw "Missing path component: $current"
        }
        $item = Get-Item -LiteralPath $current -Force
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw "Reparse-point path is not allowed: $current"
        }
    }
    $full
}

function Test-ExactStringSet {
    param([string[]]$Actual, [string[]]$Expected)
    if ($Actual.Count -ne $Expected.Count) { return $false }
    foreach ($item in $Expected) {
        if (@($Actual | Where-Object { $_ -ceq $item }).Count -ne 1) { return $false }
    }
    $true
}

function Get-HostControlReview {
    param([Parameter(Mandatory)][string]$Path)
    $manifestFull = Assert-HostControlNoReparse $Path
    if (-not (Test-Path -LiteralPath $manifestFull -PathType Leaf)) { throw 'Manifest path is not a file.' }
    $manifest = Get-Content -Raw -LiteralPath $manifestFull | ConvertFrom-Json
    $expectedCaseOrder = @(
        'signature-negative',
        'signed-whitelist-positive',
        'relocated-chain-sentinel',
        'pre-no-whitelist-baseline',
        'no-whitelist-negative'
    )
    $expectedMethods = @('AddInstallScriptToWhiteList', 'RunInstallScript', 'GetInstallScriptExitCode')
    $interactiveSystemCmd = $manifest.schema -ceq 'steam-service-host-local-pack/v3'
    if (-not $interactiveSystemCmd -and $manifest.schema -cne 'steam-service-host-local-pack/v2') {
        throw 'Host-local manifest schema is invalid.'
    }
    if ($manifest.active_policy.active_ipc_allowed -ne $true -or
        $manifest.active_policy.game_launch_permitted -ne $false -or
        $manifest.active_policy.interactive_steam_client_required -ne $true -or
        $manifest.active_policy.steam_service_mutation_permitted -ne $false -or
        (@($manifest.active_policy.allowed_case_order) -join "`n") -cne ($expectedCaseOrder -join "`n") -or
        -not (Test-ExactStringSet @($manifest.active_policy.allowed_methods) $expectedMethods)) {
        throw 'Host-local manifest policy is invalid.'
    }
    if ($interactiveSystemCmd) {
        if ($manifest.active_policy.evidence_mode -cne 'interactive-system-cmd' -or
            $manifest.active_policy.interactive_system_cmd_permitted -ne $true -or
            $manifest.active_policy.interactive_system_cmd_lifetime -cne 'until-user-exit' -or
            [uint32]$manifest.active_policy.interactive_system_cmd_timeout_milliseconds -ne 0 -or
            $manifest.active_policy.interactive_system_cmd_job_cleanup_required -ne $true -or
            $manifest.run.no_whitelist.interactive_system_cmd -ne $false -or
            $manifest.run.relocated.interactive_system_cmd -ne $true -or
            $manifest.sentinel.expected_schema_version -ne 3 -or
            $manifest.sentinel.evidence_mode -cne 'interactive-system-cmd' -or
            $manifest.sentinel.interactive_desktop -cne 'winsta0\default' -or
            $manifest.sentinel.interactive_lifetime -cne 'until-user-exit' -or
            [uint32]$manifest.sentinel.interactive_timeout_milliseconds -ne 0 -or
            $manifest.sentinel.interactive_job_kill_on_close_required -ne $true -or
            [uint32]$manifest.expected_requester.session_id -eq 0) {
            throw 'Interactive SYSTEM cmd policy is invalid.'
        }
    }
    $packRoot = Assert-HostControlNoReparse ([string]$manifest.pack_root)
    if ($packRoot -cne [IO.Path]::GetDirectoryName($manifestFull)) { throw 'Manifest is not inside its exact pack root.' }
    $evidenceDirectory = Assert-HostControlNoReparse ([string]$manifest.evidence_directory)
    if ($evidenceDirectory -cne (Join-Path $packRoot 'evidence')) { throw 'Evidence directory path mismatch.' }
    if (@(Get-ChildItem -LiteralPath $evidenceDirectory -File -Recurse -Force).Count -ne 0) {
        throw 'Evidence directory already contains a file.'
    }

    $expectedDirectories = @(
        'evidence',
        'evidence\no-whitelist',
        'evidence\relocated',
        'no-whitelist',
        'relocated-root',
        'signature-negative',
        'signed-input'
    )
    if (-not (Test-ExactStringSet @($manifest.pack_tree.directories) $expectedDirectories)) {
        throw 'Manifest directory set mismatch.'
    }
    $actualDirectories = @(Get-ChildItem -LiteralPath $packRoot -Directory -Recurse -Force | ForEach-Object {
        $_.FullName.Substring($packRoot.Length + 1)
    })
    if (-not (Test-ExactStringSet $actualDirectories $expectedDirectories)) { throw 'Pack directory tree mismatch.' }

    $expectedFiles = @(
        'signed-input\installscript.vdf',
        'signature-negative\installscript-one-byte-signature.vdf',
        'no-whitelist\launcher.exe',
        'no-whitelist\unsigned-run.vdf',
        'relocated-root\launcher.exe',
        'relocated-root\unsigned-run.vdf'
    )
    $files = @($manifest.pack_tree.files)
    $relativeFiles = @($files | ForEach-Object { [string]$_.relative_path })
    if (-not (Test-ExactStringSet $relativeFiles $expectedFiles)) { throw 'Manifest file set mismatch.' }
    $actualFiles = @(Get-ChildItem -LiteralPath $packRoot -File -Recurse -Force | ForEach-Object {
        $_.FullName.Substring($packRoot.Length + 1)
    })
    if (-not (Test-ExactStringSet $actualFiles ($expectedFiles + @('manifest.json', 'marker.json')))) {
        throw 'Pack file tree mismatch.'
    }
    $fileByRelative = @{}
    foreach ($entry in $files) {
        $relative = [string]$entry.relative_path
        $candidate = Assert-HostControlNoReparse (Join-Path $packRoot $relative)
        if (-not (Test-HostControlContained $packRoot $candidate) -or
            -not (Test-Path -LiteralPath $candidate -PathType Leaf)) {
            throw "Invalid manifest file path: $relative"
        }
        $item = Get-Item -LiteralPath $candidate -Force
        if ($item.Length -ne [int64]$entry.length -or
            (Get-HostControlSha256 $candidate) -cne ([string]$entry.sha256).ToUpperInvariant()) {
            throw "Manifest file readback mismatch: $relative"
        }
        $fileByRelative[$relative] = $candidate
    }

    $markerPath = Assert-HostControlNoReparse (Join-Path $packRoot 'marker.json')
    $marker = Get-Content -Raw -LiteralPath $markerPath | ConvertFrom-Json
    $manifestHash = Get-HostControlSha256 $manifestFull
    $activePolicyBytes = [Text.UTF8Encoding]::new($false).GetBytes((
        $manifest.active_policy | ConvertTo-Json -Depth 6 -Compress
    ))
    $expectedMarkerSchema = if ($interactiveSystemCmd) {
        'steam-service-host-local-marker/v3'
    } else {
        'steam-service-host-local-marker/v2'
    }
    if ($marker.schema -cne $expectedMarkerSchema -or
        $marker.run_id -cne $manifest.run_id -or
        $marker.manifest_relative_path -cne 'manifest.json' -or
        $marker.manifest_sha256 -cne $manifestHash -or
        [int64]$marker.manifest_length -ne (Get-Item -LiteralPath $manifestFull).Length -or
        $marker.active_policy_sha256 -cne (Get-HostControlBytesSha256 $activePolicyBytes) -or
        $marker.game_launch_permitted -ne $false) {
        throw 'Host-local marker policy is invalid.'
    }

    $controllerPath = Assert-HostControlNoReparse ([string]$manifest.tooling.controller.path)
    $frameModulePath = Assert-HostControlNoReparse ([string]$manifest.tooling.frame_module.path)
    $expectedControllerPath = Assert-HostControlNoReparse $PSCommandPath
    $expectedFrameModulePath = Assert-HostControlNoReparse (Join-Path $PSScriptRoot 'steam_service_ipc_frames.ps1')
    if ($controllerPath -cne $expectedControllerPath -or $frameModulePath -cne $expectedFrameModulePath -or
        (Get-HostControlSha256 $controllerPath) -cne ([string]$manifest.tooling.controller.sha256).ToUpperInvariant() -or
        (Get-HostControlSha256 $frameModulePath) -cne ([string]$manifest.tooling.frame_module.sha256).ToUpperInvariant()) {
        throw 'Controller or frame-module binding mismatch.'
    }
    $targetFiles = [ordered]@{}
    foreach ($name in @('steam_client', 'service_exe', 'service_dll', 'steam_exe', 'steam_webhelper')) {
        $binding = $manifest.target.$name
        $targetPath = Assert-HostControlNoReparse ([string]$binding.path)
        if (-not (Test-Path -LiteralPath $targetPath -PathType Leaf) -or
            (Get-Item -LiteralPath $targetPath).Length -ne [int64]$binding.length -or
            (Get-HostControlSha256 $targetPath) -cne ([string]$binding.sha256).ToUpperInvariant()) {
            throw "Target build binding mismatch: $name"
        }
        $targetFiles[$name] = $targetPath
    }
    $runProcessLogPath = Assert-HostControlNoReparse (Join-Path (
        [IO.Path]::GetDirectoryName($targetFiles.steam_exe)
    ) 'logs\runprocess_log.txt') -AllowMissingLeaf
    if ((Test-Path -LiteralPath $runProcessLogPath) -and
        -not (Test-Path -LiteralPath $runProcessLogPath -PathType Leaf)) {
        throw 'Steam run-process log path is not a file.'
    }

    $signedPath = $fileByRelative['signed-input\installscript.vdf']
    $negativePath = $fileByRelative['signature-negative\installscript-one-byte-signature.vdf']
    if ((Get-HostControlSha256 $signedPath) -cne ([string]$manifest.signed_vdf.sha256).ToUpperInvariant() -or
        (Get-HostControlSha256 $negativePath) -cne ([string]$manifest.negative_signature.sha256).ToUpperInvariant() -or
        $manifest.negative_signature.changed_byte_count -ne 1 -or
        $manifest.negative_signature.source_sha256 -cne $manifest.signed_vdf.sha256) {
        throw 'Signed or signature-negative manifest binding is invalid.'
    }
    $signedBytes = [IO.File]::ReadAllBytes($signedPath)
    $negativeBytes = [IO.File]::ReadAllBytes($negativePath)
    if ($signedBytes.Length -ne $negativeBytes.Length) { throw 'Signature-negative length mismatch.' }
    $different = @()
    for ($index = 0; $index -lt $signedBytes.Length; $index++) {
        if ($signedBytes[$index] -ne $negativeBytes[$index]) { $different += $index }
    }
    if ($different.Count -ne 1 -or $different[0] -ne [int]$manifest.negative_signature.offset_zero_based) {
        throw 'Signature-negative byte delta mismatch.'
    }

    $noWhitelistVdf = $fileByRelative[[string]$manifest.run.no_whitelist.vdf_relative_path]
    $noWhitelistLauncher = $fileByRelative[[string]$manifest.run.no_whitelist.launcher_relative_path]
    $relocatedVdf = $fileByRelative[[string]$manifest.run.relocated.vdf_relative_path]
    $relocatedLauncher = $fileByRelative[[string]$manifest.run.relocated.launcher_relative_path]
    if ([IO.Path]::GetDirectoryName($noWhitelistVdf) -cne [IO.Path]::GetDirectoryName($noWhitelistLauncher) -or
        [IO.Path]::GetDirectoryName($relocatedVdf) -cne [IO.Path]::GetDirectoryName($relocatedLauncher) -or
        [IO.Path]::GetDirectoryName($noWhitelistVdf) -ceq [IO.Path]::GetDirectoryName($relocatedVdf)) {
        throw 'Run VDF and launcher colocation is invalid.'
    }
    foreach ($case in @($manifest.run.no_whitelist, $manifest.run.relocated)) {
        $output = Get-HostControlFixedPath ([string]$case.output_path)
        if (-not (Test-HostControlContained $evidenceDirectory $output) -or
            [IO.Path]::GetFileName($output) -cne 'sentinel.json' -or
            (Test-Path -LiteralPath $output)) {
            throw 'Sentinel output path is not fresh and contained.'
        }
    }
    if ([uint32]$manifest.run.app_id -ne 431960 -or $manifest.run.wire_boolean -ne $false -or
        $manifest.run.no_whitelist.process_decoded -cne $noWhitelistLauncher -or
        $manifest.run.relocated.process_decoded -cne $relocatedLauncher) {
        throw 'Fixed run policy is invalid.'
    }
    $expectedNoWhitelistCommand = '--run-dir "' + [IO.Path]::GetDirectoryName([string]$manifest.run.no_whitelist.output_path) +
        '" --output "' + [string]$manifest.run.no_whitelist.output_path + '"'
    $expectedRelocatedCommand = '--run-dir "' + [IO.Path]::GetDirectoryName([string]$manifest.run.relocated.output_path) +
        '" --output "' + [string]$manifest.run.relocated.output_path + '"'
    if ($interactiveSystemCmd) {
        $expectedRelocatedCommand += ' --interactive-system-cmd --expected-session-id ' +
            [uint32]$manifest.expected_requester.session_id
    }
    if ($manifest.run.no_whitelist.command_decoded -cne $expectedNoWhitelistCommand -or
        $manifest.run.relocated.command_decoded -cne $expectedRelocatedCommand) {
        throw 'Launcher command policy is invalid.'
    }
    $interactiveCmdPath = $null
    $interactiveCmdSha256 = $null
    if ($interactiveSystemCmd) {
        $interactiveCmdPath = Assert-HostControlNoReparse ([string]$manifest.sentinel.interactive_cmd.path)
        $expectedInteractiveCmdPath = Assert-HostControlNoReparse (Join-Path ([Environment]::SystemDirectory) 'cmd.exe')
        if ($interactiveCmdPath -ine $expectedInteractiveCmdPath -or
            -not (Test-Path -LiteralPath $interactiveCmdPath -PathType Leaf) -or
            (Get-Item -LiteralPath $interactiveCmdPath).Length -ne [int64]$manifest.sentinel.interactive_cmd.length -or
            (Get-HostControlSha256 $interactiveCmdPath) -cne ([string]$manifest.sentinel.interactive_cmd.sha256).ToUpperInvariant()) {
            throw 'Interactive cmd.exe binding is invalid.'
        }
        $interactiveCmdSha256 = Get-HostControlSha256 $interactiveCmdPath
    }

    $negativeWhitelistPayload = New-IpcWhitelistPayload -SignedVdfPath $negativePath -InstallRoot ([IO.Path]::GetDirectoryName($relocatedLauncher)) -SelectorForm CurrentClient
    $positiveWhitelistPayload = New-IpcWhitelistPayload -SignedVdfPath $signedPath -InstallRoot ([IO.Path]::GetDirectoryName($relocatedLauncher)) -SelectorForm CurrentClient
    $noWhitelistRunPayload = New-IpcRunPayload -VdfPath $noWhitelistVdf -Argument ([uint32]$manifest.run.app_id) -WireBoolean $false -SelectorForm CurrentClient
    $relocatedRunPayload = New-IpcRunPayload -VdfPath $relocatedVdf -Argument ([uint32]$manifest.run.app_id) -WireBoolean $false -SelectorForm CurrentClient
    $queryPayload = Get-IpcQueryPayload -SelectorForm CurrentClient
    $frames = [ordered]@{
        negative_whitelist = New-IpcFrame $negativeWhitelistPayload
        positive_whitelist = New-IpcFrame $positiveWhitelistPayload
        no_whitelist_run = New-IpcFrame $noWhitelistRunPayload
        relocated_run = New-IpcFrame $relocatedRunPayload
        query = New-IpcFrame $queryPayload
    }
    $derivedFrameHashes = [ordered]@{
        negative_whitelist = Get-IpcSha256 $frames.negative_whitelist
        positive_whitelist = Get-IpcSha256 $frames.positive_whitelist
        no_whitelist_run = Get-IpcSha256 $frames.no_whitelist_run
        relocated_run = Get-IpcSha256 $frames.relocated_run
        query = Get-IpcSha256 $frames.query
    }
    foreach ($name in @('negative_whitelist', 'positive_whitelist', 'no_whitelist_run', 'relocated_run', 'query')) {
        if ($derivedFrameHashes[$name] -cne ([string]$manifest.tooling.frame_sha256.$name).ToUpperInvariant()) {
            throw "Generated frame binding mismatch: $name"
        }
    }
    $parsedNegative = Read-IpcWhitelistPayload (Read-IpcFrame $frames.negative_whitelist) -SelectorForm CurrentClient
    $parsedPositive = Read-IpcWhitelistPayload (Read-IpcFrame $frames.positive_whitelist) -SelectorForm CurrentClient
    $parsedNoWhitelist = Read-IpcRunPayload (Read-IpcFrame $frames.no_whitelist_run) -SelectorForm CurrentClient
    $parsedRelocated = Read-IpcRunPayload (Read-IpcFrame $frames.relocated_run) -SelectorForm CurrentClient
    [void](Read-IpcQueryPayload (Read-IpcFrame $frames.query) -SelectorForm CurrentClient)
    if ($parsedNegative.signed_vdf_path -cne $negativePath -or
        $parsedPositive.signed_vdf_path -cne $signedPath -or
        $parsedNoWhitelist.vdf_path -cne $noWhitelistVdf -or
        $parsedRelocated.vdf_path -cne $relocatedVdf) {
        throw 'Current-client frame parse-back mismatch.'
    }

    [pscustomobject]@{
        manifest = $manifest
        manifest_path = $manifestFull
        manifest_sha256 = $manifestHash
        marker_path = $markerPath
        marker_sha256 = Get-HostControlSha256 $markerPath
        controller_path = $controllerPath
        controller_sha256 = Get-HostControlSha256 $controllerPath
        frame_module_path = $frameModulePath
        frame_module_sha256 = Get-HostControlSha256 $frameModulePath
        target_files = [pscustomobject]$targetFiles
        pack_root = $packRoot
        evidence_directory = $evidenceDirectory
        signed_vdf_path = $signedPath
        negative_vdf_path = $negativePath
        no_whitelist_vdf_path = $noWhitelistVdf
        relocated_vdf_path = $relocatedVdf
        relocated_root = [IO.Path]::GetDirectoryName($relocatedLauncher)
        runprocess_log_path = $runProcessLogPath
        no_whitelist_output = [string]$manifest.run.no_whitelist.output_path
        relocated_output = [string]$manifest.run.relocated.output_path
        evidence_mode = if ($interactiveSystemCmd) { 'interactive-system-cmd' } else { 'identity-sentinel' }
        expected_requester_session_id = if ($interactiveSystemCmd) {
            [uint32]$manifest.expected_requester.session_id
        } else { [uint32]0 }
        interactive_cmd_path = $interactiveCmdPath
        interactive_cmd_sha256 = $interactiveCmdSha256
        interactive_cmd_desktop = if ($interactiveSystemCmd) {
            [string]$manifest.sentinel.interactive_desktop
        } else { $null }
        interactive_cmd_timeout_milliseconds = if ($interactiveSystemCmd) {
            [uint32]$manifest.sentinel.interactive_timeout_milliseconds
        } else { [uint32]0 }
        frames = [pscustomobject]$frames
        fixtures = [ordered]@{
            selector_form = 'CurrentClient'
            whitelist_method = 'AddInstallScriptToWhiteList'
            whitelist_selector = '0x1b7449c5'
            whitelist_fencepost = '0x1b83cb83'
            run_method = 'RunInstallScript'
            run_selector = '0xb1e810f9'
            run_fencepost = '0xb1f810b9'
            query_method = 'GetInstallScriptExitCode'
            negative_whitelist_frame_sha256 = $derivedFrameHashes.negative_whitelist
            positive_whitelist_frame_sha256 = $derivedFrameHashes.positive_whitelist
            no_whitelist_run_frame_sha256 = $derivedFrameHashes.no_whitelist_run
            relocated_run_frame_sha256 = $derivedFrameHashes.relocated_run
            query_frame_sha256 = $derivedFrameHashes.query
        }
    }
}

function Read-HostSharedFileBytes {
    param(
        [Parameter(Mandatory)][string]$Path,
        [ValidateRange(1, 67108864)][int]$MaximumLength = 67108864,
        [switch]$AllowMissingLeaf
    )
    $full = Assert-HostControlNoReparse $Path -AllowMissingLeaf:$AllowMissingLeaf
    if (-not (Test-Path -LiteralPath $full -PathType Leaf)) {
        if ($AllowMissingLeaf -and -not (Test-Path -LiteralPath $full)) { return ,([byte[]]::new(0)) }
        throw "Shared file is unavailable: $full"
    }
    $share = [IO.FileShare]([int][IO.FileShare]::ReadWrite -bor [int][IO.FileShare]::Delete)
    $stream = [IO.File]::Open($full, [IO.FileMode]::Open, [IO.FileAccess]::Read, $share)
    try {
        if ($stream.Length -gt $MaximumLength) { throw "Shared file exceeds the length bound: $full" }
        $bytes = [byte[]]::new([int]$stream.Length)
        $offset = 0
        while ($offset -lt $bytes.Length) {
            $read = $stream.Read($bytes, $offset, $bytes.Length - $offset)
            if ($read -le 0) { throw "Unexpected end of shared file: $full" }
            $offset += $read
        }
        return ,$bytes
    } finally { $stream.Dispose() }
}

function Get-HostAppendedRunProcessLogRecord {
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][AllowEmptyCollection()][byte[]]$BeforeBytes,
        [Parameter(Mandatory)][uint32]$AppId,
        [Parameter(Mandatory)][string]$ExpectedLauncherPath,
        [bool]$BeforeExists = $true
    )
    $full = Assert-HostControlNoReparse $Path
    $launcher = Get-HostControlFixedPath $ExpectedLauncherPath
    if ($launcher -cne $ExpectedLauncherPath) { throw 'Expected launcher path is noncanonical.' }
    $afterBytes = Read-HostSharedFileBytes $full
    if ($afterBytes.Length -lt $BeforeBytes.Length) { throw 'Run-process log was truncated.' }
    for ($index = 0; $index -lt $BeforeBytes.Length; $index++) {
        if ($afterBytes[$index] -ne $BeforeBytes[$index]) { throw 'Run-process log prefix changed.' }
    }
    $deltaLength = $afterBytes.Length - $BeforeBytes.Length
    $deltaBytes = [byte[]]::new($deltaLength)
    if ($deltaLength -gt 0) { [Array]::Copy($afterBytes, $BeforeBytes.Length, $deltaBytes, 0, $deltaLength) }
    $deltaText = [Text.UTF8Encoding]::new($false, $true).GetString($deltaBytes)
    $pattern = '^\d{2}/\d{2}/\d{2} \d{2}:\d{2}:\d{2} \[AppID ' + $AppId +
        '\] Executable not white-listed:  ' + [Regex]::Escape($launcher) + ' GLE 0$'
    $lines = @($deltaText -split "`r?`n" | Where-Object { $_.Length -gt 0 })
    $matchedLines = @($lines | Where-Object { $_ -cmatch $pattern })
    [ordered]@{
        source_path = $full
        before_exists = $BeforeExists
        after_exists = $true
        before_length = $BeforeBytes.Length
        before_sha256 = Get-HostControlBytesSha256 $BeforeBytes
        after_length = $afterBytes.Length
        after_sha256 = Get-HostControlBytesSha256 $afterBytes
        prefix_unchanged = $true
        delta_length = $deltaLength
        delta_sha256 = Get-HostControlBytesSha256 $deltaBytes
        delta_text = $deltaText
        exact_match_count = $matchedLines.Count
        matching_lines = @($matchedLines)
        expected_rejection_log_observed = $matchedLines.Count -eq 1
    }
}

$preloadManifestPath = Assert-HostControlNoReparse $ManifestPath
$preloadManifestHash = Get-HostControlSha256 $preloadManifestPath
$preloadManifest = Get-Content -Raw -LiteralPath $preloadManifestPath | ConvertFrom-Json
$preloadInteractiveSystemCmd = $preloadManifest.schema -ceq 'steam-service-host-local-pack/v3'
if (-not $preloadInteractiveSystemCmd -and $preloadManifest.schema -cne 'steam-service-host-local-pack/v2') {
    throw 'Preload manifest schema mismatch.'
}
$preloadMarkerPath = Assert-HostControlNoReparse (Join-Path ([IO.Path]::GetDirectoryName($preloadManifestPath)) 'marker.json')
$preloadMarkerHash = Get-HostControlSha256 $preloadMarkerPath
$preloadMarker = Get-Content -Raw -LiteralPath $preloadMarkerPath | ConvertFrom-Json
$preloadControllerPath = Assert-HostControlNoReparse ([string]$preloadManifest.tooling.controller.path)
$preloadFrameModulePath = Assert-HostControlNoReparse ([string]$preloadManifest.tooling.frame_module.path)
$preloadExpectedMarkerSchema = if ($preloadInteractiveSystemCmd) {
    'steam-service-host-local-marker/v3'
} else {
    'steam-service-host-local-marker/v2'
}
if ($preloadControllerPath -cne (Assert-HostControlNoReparse $PSCommandPath) -or
    $preloadFrameModulePath -cne (Assert-HostControlNoReparse (Join-Path $PSScriptRoot 'steam_service_ipc_frames.ps1')) -or
    (Get-HostControlSha256 $preloadControllerPath) -cne ([string]$preloadManifest.tooling.controller.sha256).ToUpperInvariant() -or
    (Get-HostControlSha256 $preloadFrameModulePath) -cne ([string]$preloadManifest.tooling.frame_module.sha256).ToUpperInvariant() -or
    $preloadMarker.schema -cne $preloadExpectedMarkerSchema -or
    $preloadMarker.manifest_sha256 -cne $preloadManifestHash) {
    throw 'Preload manifest, marker, controller, or frame-module binding mismatch.'
}
if ($Active) {
    if (-not $AcknowledgeHostLocalRisk) { throw 'Active host-local control requires -AcknowledgeHostLocalRisk.' }
    foreach ($binding in @(
        $ExpectedManifestSha256,
        $ExpectedMarkerSha256,
        $ExpectedControllerSha256,
        $ExpectedFrameModuleSha256
    )) {
        if ([string]::IsNullOrWhiteSpace($binding)) { throw 'Active host-local control requires all expected artifact hashes from plan mode.' }
    }
    if ($preloadManifestHash -cne $ExpectedManifestSha256.ToUpperInvariant() -or
        $preloadMarkerHash -cne $ExpectedMarkerSha256.ToUpperInvariant() -or
        (Get-HostControlSha256 $preloadControllerPath) -cne $ExpectedControllerSha256.ToUpperInvariant() -or
        (Get-HostControlSha256 $preloadFrameModulePath) -cne $ExpectedFrameModuleSha256.ToUpperInvariant()) {
        throw 'Active expected artifact binding mismatch.'
    }
}
. $preloadFrameModulePath
$review = Get-HostControlReview $preloadManifestPath
if ($review.manifest_sha256 -cne $preloadManifestHash -or $review.marker_sha256 -cne $preloadMarkerHash) {
    throw 'Artifact binding changed during review.'
}
if (-not $Active) {
    [pscustomobject]@{
        schema = 'steam-service-host-local-control-plan/v1'
        run_id = $review.manifest.run_id
        status = 'reviewed-no-ipc'
        active_requested = $false
        active_ipc_sent = $false
        service_mutated = $false
        game_launch_requested = $false
        evidence_mode = $review.evidence_mode
        interactive_cmd_desktop = $review.interactive_cmd_desktop
        interactive_cmd_timeout_milliseconds = $review.interactive_cmd_timeout_milliseconds
        fixtures = $review.fixtures
        manifest_sha256 = $review.manifest_sha256
        marker_sha256 = $review.marker_sha256
        controller_sha256 = $review.controller_sha256
        frame_module_sha256 = $review.frame_module_sha256
    }
    return
}

$nativeSource = @'
using System;
using System.Runtime.InteropServices;
public static class SteamHostLocalControlNative {
 [DllImport("kernel32.dll")] public static extern IntPtr GetCurrentProcess();
 [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)] public static extern IntPtr OpenFileMapping(uint a,bool b,string c);
 [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)] public static extern IntPtr OpenEvent(uint a,bool b,string c);
 [DllImport("kernel32.dll", SetLastError=true)] public static extern IntPtr CreateEvent(IntPtr a,bool b,bool c,string d);
 [DllImport("kernel32.dll", SetLastError=true)] public static extern IntPtr MapViewOfFile(IntPtr a,uint b,uint c,uint d,UIntPtr e);
 [DllImport("kernel32.dll", SetLastError=true)] public static extern bool UnmapViewOfFile(IntPtr a);
 [DllImport("kernel32.dll", SetLastError=true)] public static extern bool CloseHandle(IntPtr a);
 [DllImport("kernel32.dll", SetLastError=true)] public static extern uint WaitForSingleObject(IntPtr a,uint b);
 [DllImport("kernel32.dll", SetLastError=true)] public static extern bool SetEvent(IntPtr a);
 [DllImport("kernel32.dll", SetLastError=true)] public static extern bool ResetEvent(IntPtr a);
 [DllImport("kernel32.dll", SetLastError=true)] public static extern bool WriteFile(IntPtr a,byte[] b,uint c,out uint d,IntPtr e);
 [DllImport("kernel32.dll", SetLastError=true)] public static extern bool ReadFile(IntPtr a,byte[] b,uint c,out uint d,IntPtr e);
 [DllImport("kernel32.dll", SetLastError=true)] public static extern bool PeekNamedPipe(IntPtr a,IntPtr b,uint c,IntPtr d,out uint e,IntPtr f);
 [DllImport("advapi32.dll", SetLastError=true)] public static extern bool OpenProcessToken(IntPtr a,uint b,out IntPtr c);
 [DllImport("advapi32.dll", SetLastError=true)] public static extern bool GetTokenInformation(IntPtr a,int b,IntPtr c,uint d,out uint e);
 [DllImport("advapi32.dll", CharSet=CharSet.Unicode, SetLastError=true)] public static extern bool ConvertSidToStringSid(IntPtr a,out IntPtr b);
 [DllImport("kernel32.dll")] public static extern IntPtr LocalFree(IntPtr a);
}
'@

function Initialize-HostNative {
    if (-not ('SteamHostLocalControlNative' -as [type])) { Add-Type -TypeDefinition $nativeSource }
}

function Get-HostTokenRecord {
    $token = [IntPtr]::Zero
    if (-not [SteamHostLocalControlNative]::OpenProcessToken(
        [SteamHostLocalControlNative]::GetCurrentProcess(), 8, [ref]$token
    )) { throw 'Could not open requester token.' }
    try {
        $scalar = [Runtime.InteropServices.Marshal]::AllocHGlobal(4)
        try {
            $needed = [uint32]0
            if (-not [SteamHostLocalControlNative]::GetTokenInformation($token, 20, $scalar, 4, [ref]$needed)) { throw 'Could not read token elevation.' }
            $elevated = [Runtime.InteropServices.Marshal]::ReadInt32($scalar) -ne 0
            if (-not [SteamHostLocalControlNative]::GetTokenInformation($token, 18, $scalar, 4, [ref]$needed)) { throw 'Could not read token elevation type.' }
            $elevationType = [Runtime.InteropServices.Marshal]::ReadInt32($scalar)
        } finally { [Runtime.InteropServices.Marshal]::FreeHGlobal($scalar) }
        $needed = [uint32]0
        [void][SteamHostLocalControlNative]::GetTokenInformation($token, 25, [IntPtr]::Zero, 0, [ref]$needed)
        $buffer = [Runtime.InteropServices.Marshal]::AllocHGlobal($needed)
        try {
            if (-not [SteamHostLocalControlNative]::GetTokenInformation($token, 25, $buffer, $needed, [ref]$needed)) { throw 'Could not read token integrity.' }
            $sid = [Runtime.InteropServices.Marshal]::ReadIntPtr($buffer)
            $text = [IntPtr]::Zero
            if (-not [SteamHostLocalControlNative]::ConvertSidToStringSid($sid, [ref]$text)) { throw 'Could not stringify token integrity.' }
            try { $integrity = [Runtime.InteropServices.Marshal]::PtrToStringUni($text) }
            finally { [void][SteamHostLocalControlNative]::LocalFree($text) }
        } finally { [Runtime.InteropServices.Marshal]::FreeHGlobal($buffer) }
        $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = [Security.Principal.WindowsPrincipal]::new($identity)
        [ordered]@{
            identity = $identity.Name
            sid = $identity.User.Value
            session_id = [uint32][Diagnostics.Process]::GetCurrentProcess().SessionId
            is_administrator = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
            is_elevated = $elevated
            elevation_type = $elevationType
            integrity_level_sid = $integrity
        }
    } finally { [void][SteamHostLocalControlNative]::CloseHandle($token) }
}

function Get-HostServiceRecord {
    $service = Get-CimInstance Win32_Service -Filter "Name='Steam Client Service'"
    if ($null -eq $service) { throw 'Steam Client Service is absent.' }
    $process = if ($service.ProcessId -ne 0) { Get-Process -Id $service.ProcessId -ErrorAction SilentlyContinue }
    [ordered]@{
        state = $service.State
        process_id = [uint32]$service.ProcessId
        start_name = $service.StartName
        start_mode = $service.StartMode
        path_name = $service.PathName
        handle_count = if ($process) { $process.HandleCount } else { $null }
        thread_count = if ($process) { $process.Threads.Count } else { $null }
    }
}

function Test-NoGameProcessGate {
    param(
        [Parameter(Mandatory)][string]$ExpectedSteamExePath,
        [Parameter(Mandatory)][string]$ExpectedSteamWebHelperPath
    )
    $service = Get-CimInstance Win32_Service -Filter "Name='Steam Client Service'"
    $servicePid = if ($service) { [uint32]$service.ProcessId } else { 0 }
    $processes = @(Get-CimInstance Win32_Process -ErrorAction Stop)
    $gameBlocked = @($processes | Where-Object {
        $name = [IO.Path]::GetFileNameWithoutExtension([string]$_.Name)
        $path = [string]$_.ExecutablePath
        $_.ProcessId -ne $servicePid -and (
            $name -imatch '^(cs2|hl2|dota2|gameoverlayui|wallpaper32|wallpaper64|wallpaper|ui32|webwallpaper32)$' -or
            (-not [string]::IsNullOrWhiteSpace($path) -and $path -imatch '\\steamapps\\common\\')
        )
    } | ForEach-Object {
        [ordered]@{ name = $_.Name; process_id = [uint32]$_.ProcessId; path = $_.ExecutablePath }
    })
    $steamProcesses = @($processes | Where-Object { $_.Name -imatch '^steam(webhelper)?\.exe$' })
    $steamClient = @($steamProcesses | Where-Object {
        $_.Name -ieq 'steam.exe' -and [string]$_.ExecutablePath -ieq $ExpectedSteamExePath
    })
    $steamWebHelpers = @($steamProcesses | Where-Object {
        $_.Name -ieq 'steamwebhelper.exe' -and [string]$_.ExecutablePath -ieq $ExpectedSteamWebHelperPath
    })
    $unexpectedSteam = @($steamProcesses | Where-Object {
        -not (
            ($_.Name -ieq 'steam.exe' -and [string]$_.ExecutablePath -ieq $ExpectedSteamExePath) -or
            ($_.Name -ieq 'steamwebhelper.exe' -and [string]$_.ExecutablePath -ieq $ExpectedSteamWebHelperPath)
        )
    } | ForEach-Object {
        [ordered]@{ name = $_.Name; process_id = [uint32]$_.ProcessId; path = $_.ExecutablePath }
    })
    $blocked = @($gameBlocked) + @($unexpectedSteam)
    $observedSteam = @($steamProcesses | ForEach-Object {
        [ordered]@{ name = $_.Name; process_id = [uint32]$_.ProcessId; path = $_.ExecutablePath }
    })
    [pscustomobject]@{
        passed = $blocked.Count -eq 0 -and $steamClient.Count -eq 1 -and $steamWebHelpers.Count -ge 1
        blocked = $blocked
        observed_steam_processes = $observedSteam
        steam_client_required = $true
        steam_client_process_id = if ($steamClient.Count -eq 1) { [uint32]$steamClient[0].ProcessId } else { $null }
        steam_client_count = $steamClient.Count
        steam_webhelper_count = $steamWebHelpers.Count
    }
}

function Get-PinnedFileRecord {
    param([string]$Path, [string]$ExpectedHash)
    $full = Assert-HostControlNoReparse $Path
    $hash = Get-HostControlSha256 $full
    if ($hash -cne $ExpectedHash.ToUpperInvariant()) { throw "Pinned binary hash mismatch: $full" }
    $signature = Get-AuthenticodeSignature -LiteralPath $full
    if ($signature.Status -ne [Management.Automation.SignatureStatus]::Valid) { throw "Pinned binary signature is not valid: $full" }
    [ordered]@{ path = $full; length = (Get-Item -LiteralPath $full).Length; sha256 = $hash; signature_status = [string]$signature.Status }
}

function Get-HostFrozenArtifactRecord {
    param([Parameter(Mandatory)]$Expected)
    $bindings = @(
        [ordered]@{ name = 'manifest'; path = $Expected.manifest_path; sha256 = $Expected.manifest_sha256 },
        [ordered]@{ name = 'marker'; path = $Expected.marker_path; sha256 = $Expected.marker_sha256 },
        [ordered]@{ name = 'controller'; path = $Expected.controller_path; sha256 = $Expected.controller_sha256 },
        [ordered]@{ name = 'frame-module'; path = $Expected.frame_module_path; sha256 = $Expected.frame_module_sha256 }
    ) + @($Expected.fixture_bindings)
    $records = foreach ($binding in $bindings) {
        $full = Assert-HostControlNoReparse ([string]$binding.path)
        $hash = Get-HostControlSha256 $full
        if ($hash -cne ([string]$binding.sha256).ToUpperInvariant()) {
            throw "Frozen artifact binding mismatch: $($binding.name)"
        }
        [ordered]@{
            name = [string]$binding.name
            path = $full
            length = (Get-Item -LiteralPath $full).Length
            sha256 = $hash
        }
    }
    @($records)
}

function Get-HostActivePreflight {
    param([Parameter(Mandatory)]$Expected, [ValidateSet('BothAbsent','RelocatedMayExist')][string]$OutputPolicy = 'BothAbsent')
    $token = Get-HostTokenRecord
    if ($token.identity -cne $Expected.requester_identity -or $token.sid -cne $Expected.requester_sid) { throw 'Requester identity mismatch.' }
    if ($token.is_administrator -or $token.is_elevated -or $token.integrity_level_sid -cne 'S-1-16-8192') {
        throw 'Requester must be a non-elevated medium-integrity token.'
    }
    if ($Expected.evidence_mode -ceq 'interactive-system-cmd' -and
        [uint32]$token.session_id -ne [uint32]$Expected.requester_session_id) {
        throw 'Requester session ID changed after interactive pack preparation.'
    }
    $artifacts = Get-HostFrozenArtifactRecord $Expected
    $service = Get-HostServiceRecord
    if ($service.state -cne 'Running' -or $service.process_id -eq 0 -or $service.start_name -cne 'LocalSystem') {
        throw 'Steam Client Service is not running as LocalSystem.'
    }
    $servicePathText = if ($service.path_name -match '^\s*"([^"]+)"') { $matches[1] } else { ($service.path_name -split '\s+')[0] }
    if ([IO.Path]::GetFullPath($servicePathText) -cne [IO.Path]::GetFullPath($Expected.service_exe_path)) {
        throw 'Steam Client Service image path mismatch.'
    }
    $gameGate = Test-NoGameProcessGate `
        -ExpectedSteamExePath $Expected.steam_exe_path `
        -ExpectedSteamWebHelperPath $Expected.steam_webhelper_path
    if (-not $gameGate.passed) { throw 'Idle Steam client admission failed or a game/Steam application process is running.' }
    if (Test-Path -LiteralPath $Expected.no_whitelist_output) { throw 'No-whitelist sentinel exists.' }
    if ($OutputPolicy -ceq 'BothAbsent' -and (Test-Path -LiteralPath $Expected.relocated_output)) { throw 'Relocated sentinel already exists.' }
    $runProcessLogExists = Test-Path -LiteralPath $Expected.runprocess_log_path -PathType Leaf
    $runProcessLogBytes = Read-HostSharedFileBytes $Expected.runprocess_log_path -AllowMissingLeaf
    $binaries = @(
        Get-PinnedFileRecord $Expected.steam_client_path $Expected.steam_client_sha256
        Get-PinnedFileRecord $Expected.service_exe_path $Expected.service_exe_sha256
        Get-PinnedFileRecord $Expected.service_dll_path $Expected.service_dll_sha256
        Get-PinnedFileRecord $Expected.steam_exe_path $Expected.steam_exe_sha256
        Get-PinnedFileRecord $Expected.steam_webhelper_path $Expected.steam_webhelper_sha256
    )
    [ordered]@{
        requester = $token
        service = $service
        no_game_gate = $gameGate
        frozen_artifacts = $artifacts
        binaries = $binaries
        runprocess_log = [ordered]@{
            path = $Expected.runprocess_log_path
            exists = $runProcessLogExists
            length = $runProcessLogBytes.Length
            sha256 = Get-HostControlBytesSha256 $runProcessLogBytes
        }
        output_policy = $OutputPolicy
    }
}

function Get-HostDword {
    param([IntPtr]$Address, [int]$Offset)
    [uint32][Runtime.InteropServices.Marshal]::ReadInt32($Address, $Offset)
}

function Set-HostDword {
    param([IntPtr]$Address, [int]$Offset, [uint32]$Value)
    [Runtime.InteropServices.Marshal]::WriteInt32($Address, $Offset, [int32]$Value)
}

function Read-HostPipeBytes {
    param([IntPtr]$Handle, [int]$Count, [int]$Timeout)
    $watch = [Diagnostics.Stopwatch]::StartNew()
    do {
        $available = [uint32]0
        if (-not [SteamHostLocalControlNative]::PeekNamedPipe($Handle, [IntPtr]::Zero, 0, [IntPtr]::Zero, [ref]$available, [IntPtr]::Zero)) {
            throw [ComponentModel.Win32Exception]::new([Runtime.InteropServices.Marshal]::GetLastWin32Error())
        }
        if ($available -ge $Count) { break }
        Start-Sleep -Milliseconds 5
    } while ($watch.ElapsedMilliseconds -lt $Timeout)
    if ($available -lt $Count) { throw "Timed out waiting for $Count response bytes." }
    $buffer = [byte[]]::new($Count)
    $read = [uint32]0
    if (-not [SteamHostLocalControlNative]::ReadFile($Handle, $buffer, [uint32]$Count, [ref]$read, [IntPtr]::Zero) -or $read -ne $Count) {
        throw 'Response read failed or was short.'
    }
    return ,$buffer
}

function Test-HostPipeTermination {
    param([IntPtr]$Handle, [int]$Timeout)
    $watch = [Diagnostics.Stopwatch]::StartNew()
    do {
        $available = [uint32]0
        if (-not [SteamHostLocalControlNative]::PeekNamedPipe($Handle, [IntPtr]::Zero, 0, [IntPtr]::Zero, [ref]$available, [IntPtr]::Zero)) {
            $errorCode = [Runtime.InteropServices.Marshal]::GetLastWin32Error()
            return [ordered]@{ transport_terminated = $errorCode -in @(6,109,233); win32_error = $errorCode; elapsed_milliseconds = $watch.ElapsedMilliseconds }
        }
        Start-Sleep -Milliseconds 5
    } while ($watch.ElapsedMilliseconds -lt $Timeout)
    [ordered]@{ transport_terminated = $false; win32_error = $null; elapsed_milliseconds = $watch.ElapsedMilliseconds }
}

function Invoke-HostIpcRequest {
    param(
        [Parameter(Mandatory)][ValidateSet('Whitelist','Run','Query')][string]$Operation,
        [Parameter(Mandatory)][byte[]]$Frame,
        [Parameter(Mandatory)][int]$Timeout,
        [Parameter(Mandatory)][scriptblock]$Revalidate
    )
    $mapping = [IntPtr]::Zero
    $view = [IntPtr]::Zero
    $gate = [IntPtr]::Zero
    $requestEvent = [IntPtr]::Zero
    $readHandle = [IntPtr]::Zero
    $writeHandle = [IntPtr]::Zero
    $replyEvent = [IntPtr]::Zero
    $submitted = $false
    $ready = $false
    $gateAcquired = $false
    $result = [pscustomobject]@{
        operation = $Operation
        started_at_utc = [DateTime]::UtcNow.ToString('o')
        frame_sha256 = Get-IpcSha256 $Frame
        mapping_peer_process_id = $null
        request_write_attempted = $false
        request_write_succeeded = $false
        request_bytes_expected = $Frame.Length
        request_bytes_written = 0
        request_write_count = 0
        request_written_at_utc = $null
        request_event_signaled = $false
        response_event_wait = $null
        response_header_hex = $null
        response_payload_hex = $null
        response_value = $null
        primary_error = $null
        disconnect = $null
        cleanup = @()
        finished_at_utc = $null
    }
    try {
        $mapping = [SteamHostLocalControlNative]::OpenFileMapping(6, $false, 'Global\SteamClientService_SharedMemFile')
        if ($mapping -eq [IntPtr]::Zero) { throw 'Could not open IPC mapping.' }
        $gate = [SteamHostLocalControlNative]::OpenEvent(0x00100000, $false, 'Global\SteamClientService_SharedMemLock')
        if ($gate -eq [IntPtr]::Zero) { throw 'Could not open IPC gate.' }
        if ([SteamHostLocalControlNative]::WaitForSingleObject($gate, [uint32]$Timeout) -ne 0) { throw 'IPC gate wait timed out.' }
        $gateAcquired = $true
        $view = [SteamHostLocalControlNative]::MapViewOfFile($mapping, 6, 0, 0, [UIntPtr][uint32]0x400)
        if ($view -eq [IntPtr]::Zero) { throw 'Could not map IPC state.' }
        $initialState = Get-HostDword $view 4
        $peerPid = Get-HostDword $view 8
        $result.mapping_peer_process_id = $peerPid
        if ($initialState -ne 0 -or $peerPid -eq 0) { throw 'IPC mapping state or peer PID is invalid.' }
        $requestEvent = [SteamHostLocalControlNative]::CreateEvent([IntPtr]::Zero, $true, $false, $null)
        if ($requestEvent -eq [IntPtr]::Zero) { throw 'Could not create request event.' }
        Set-HostDword $view 12 ([uint32][Diagnostics.Process]::GetCurrentProcess().Id)
        Set-HostDword $view 16 0
        Set-HostDword $view 20 0
        Set-HostDword $view 24 ([uint32]$requestEvent.ToInt64())
        Set-HostDword $view 28 0
        Set-HostDword $view 32 0
        Set-HostDword $view 4 1
        $submitted = $true
        $watch = [Diagnostics.Stopwatch]::StartNew()
        do {
            $state = Get-HostDword $view 4
            if ($state -ne 1) { break }
            Start-Sleep -Milliseconds 1
        } while ($watch.ElapsedMilliseconds -lt $Timeout)
        if ($state -ne 2) { throw 'IPC endpoint transfer failed.' }
        $readHandle = [IntPtr][uint32](Get-HostDword $view 16)
        $writeHandle = [IntPtr][uint32](Get-HostDword $view 20)
        $replyEvent = [IntPtr][uint32](Get-HostDword $view 28)
        if ($readHandle -eq [IntPtr]::Zero -or $writeHandle -eq [IntPtr]::Zero -or $replyEvent -eq [IntPtr]::Zero) { throw 'IPC endpoint transfer returned an invalid handle.' }
        Set-HostDword $view 4 3
        $ready = $true
        $watch.Restart()
        do {
            $state = Get-HostDword $view 4
            if ($state -eq 0) { break }
            Start-Sleep -Milliseconds 5
        } while ($watch.ElapsedMilliseconds -lt $Timeout)
        if ($state -ne 0) { throw 'IPC mapping did not return to idle.' }
        $gateAcquired = $false
        & $Revalidate $peerPid
        $written = [uint32]0
        $result.request_write_attempted = $true
        $writeOk = [SteamHostLocalControlNative]::WriteFile($writeHandle, $Frame, [uint32]$Frame.Length, [ref]$written, [IntPtr]::Zero)
        $result.request_bytes_written = $written
        if ($written -gt 0) { $result.request_write_count = 1 }
        if (-not $writeOk -or $written -ne $Frame.Length) { throw 'Request frame write failed or was short.' }
        $result.request_write_succeeded = $true
        $result.request_written_at_utc = [DateTime]::UtcNow.ToString('o')
        if (-not [SteamHostLocalControlNative]::SetEvent($requestEvent)) { throw 'Could not signal request event.' }
        $result.request_event_signaled = $true
        $result.response_event_wait = [SteamHostLocalControlNative]::WaitForSingleObject($replyEvent, [uint32]$Timeout)
        if ($result.response_event_wait -ne 0) { throw 'Response event timed out.' }
        $header = Read-HostPipeBytes $readHandle 4 $Timeout
        $length = [BitConverter]::ToUInt32($header, 0)
        $expectedLength = if ($Operation -ceq 'Run') { 2 } else { 5 }
        $result.response_header_hex = ConvertTo-IpcHexString $header
        if ($length -ne $expectedLength) { throw "$Operation response length was not exactly $expectedLength bytes." }
        $reply = Read-HostPipeBytes $readHandle ([int]$length) $Timeout
        $result.response_payload_hex = ConvertTo-IpcHexString $reply
        $result.response_value = switch ($Operation) {
            'Whitelist' { Read-IpcWhitelistResponse $reply }
            'Run' { Read-IpcRunResponse $reply }
            'Query' { Read-IpcQueryResponse $reply }
        }
    } catch {
        $result.primary_error = $_.Exception.Message
    } finally {
        if ($ready -and $writeHandle -ne [IntPtr]::Zero -and $requestEvent -ne [IntPtr]::Zero) {
            try {
                $close = New-IpcFrame ([byte[]](0x05))
                $closeWritten = [uint32]0
                $reset = [SteamHostLocalControlNative]::ResetEvent($requestEvent)
                $closeOk = [SteamHostLocalControlNative]::WriteFile($writeHandle, $close, [uint32]$close.Length, [ref]$closeWritten, [IntPtr]::Zero)
                $signalled = $false
                if ($closeOk -and $closeWritten -eq $close.Length) { $signalled = [SteamHostLocalControlNative]::SetEvent($requestEvent) }
                $result.disconnect = [ordered]@{
                    outer_command = 5
                    frame_length = $close.Length
                    reset_event_succeeded = $reset
                    write_succeeded = $closeOk
                    bytes_written = $closeWritten
                    event_signaled = $signalled
                    termination = if ($signalled) { Test-HostPipeTermination $readHandle $Timeout } else { $null }
                }
            } catch { $result.disconnect = [ordered]@{ cleanup_error = $_.Exception.Message } }
        }
        if ($gateAcquired -and -not $submitted -and $gate -ne [IntPtr]::Zero) {
            try { [void][SteamHostLocalControlNative]::SetEvent($gate) } catch { $result.cleanup += $_.Exception.Message }
        }
        try {
            if ($view -ne [IntPtr]::Zero -and $submitted -and -not $ready -and (Get-HostDword $view 4) -eq 2) { Set-HostDword $view 4 3 }
        } catch { $result.cleanup += $_.Exception.Message }
        foreach ($handle in @($readHandle, $writeHandle, $replyEvent, $requestEvent, $gate, $mapping)) {
            if ($handle -ne [IntPtr]::Zero) { [void][SteamHostLocalControlNative]::CloseHandle($handle) }
        }
        if ($view -ne [IntPtr]::Zero) { [void][SteamHostLocalControlNative]::UnmapViewOfFile($view) }
    }
    $result.finished_at_utc = [DateTime]::UtcNow.ToString('o')
    $result
}

function Open-HostEvidenceStream {
    param([string]$Path)
    [IO.File]::Open($Path, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::Read)
}

function Write-HostJournal {
    param([IO.FileStream]$Stream, [string]$Stage, $Data)
    $entry = [ordered]@{ timestamp_utc = [DateTime]::UtcNow.ToString('o'); stage = $Stage; data = $Data }
    $bytes = [Text.UTF8Encoding]::new($false).GetBytes(($entry | ConvertTo-Json -Depth 12 -Compress) + "`n")
    $Stream.Write($bytes, 0, $bytes.Length)
    $Stream.Flush($true)
}

function Write-HostNewJson {
    param([string]$Path, $Record)
    $stream = Open-HostEvidenceStream $Path
    try {
        $bytes = [Text.UTF8Encoding]::new($false).GetBytes(($Record | ConvertTo-Json -Depth 16))
        $stream.Write($bytes, 0, $bytes.Length)
        $stream.Flush($true)
    } finally { $stream.Dispose() }
}

function Write-HostNewText {
    param([string]$Path, [string]$Text)
    $stream = Open-HostEvidenceStream $Path
    try {
        $bytes = [Text.UTF8Encoding]::new($false).GetBytes($Text)
        $stream.Write($bytes, 0, $bytes.Length)
        $stream.Flush($true)
    } finally { $stream.Dispose() }
}

function Write-HostJsonStream {
    param([IO.FileStream]$Stream, $Record)
    if ($Stream.Length -ne 0 -or $Stream.Position -ne 0) { throw 'Reserved JSON stream is not empty.' }
    $bytes = [Text.UTF8Encoding]::new($false).GetBytes(($Record | ConvertTo-Json -Depth 16))
    $Stream.Write($bytes, 0, $bytes.Length)
    $Stream.Flush($true)
}

function Assert-HostTransport {
    param($Transport, [string]$CaseId)
    if ($Transport.primary_error) { throw "$CaseId transport failed: $($Transport.primary_error)" }
    if (-not $Transport.request_write_succeeded -or $Transport.request_write_count -ne 1) { throw "$CaseId request write was incomplete." }
    if ($null -eq $Transport.disconnect -or -not $Transport.disconnect.write_succeeded -or
        -not $Transport.disconnect.event_signaled -or -not $Transport.disconnect.termination.transport_terminated) {
        throw "$CaseId disconnect was incomplete."
    }
}

function Wait-HostOutput {
    param([string]$Path, [int]$Milliseconds)
    $watch = [Diagnostics.Stopwatch]::StartNew()
    do {
        if (Test-Path -LiteralPath $Path -PathType Leaf) { return $true }
        Start-Sleep -Milliseconds 50
    } while ($Milliseconds -eq 0 -or $watch.ElapsedMilliseconds -lt $Milliseconds)
    Test-Path -LiteralPath $Path -PathType Leaf
}

$fixtureBindings = foreach ($entry in @($review.manifest.pack_tree.files)) {
    [ordered]@{
        name = 'fixture:' + [string]$entry.relative_path
        path = Join-Path $review.pack_root ([string]$entry.relative_path)
        sha256 = ([string]$entry.sha256).ToUpperInvariant()
    }
}
$expected = [ordered]@{
    requester_identity = [string]$review.manifest.expected_requester.identity
    requester_sid = [string]$review.manifest.expected_requester.sid
    requester_session_id = $review.expected_requester_session_id
    evidence_mode = $review.evidence_mode
    manifest_path = $review.manifest_path
    manifest_sha256 = $review.manifest_sha256
    marker_path = $review.marker_path
    marker_sha256 = $review.marker_sha256
    controller_path = $review.controller_path
    controller_sha256 = $review.controller_sha256
    frame_module_path = $review.frame_module_path
    frame_module_sha256 = $review.frame_module_sha256
    fixture_bindings = @($fixtureBindings)
    steam_client_path = [string]$review.manifest.target.steam_client.path
    steam_client_sha256 = [string]$review.manifest.target.steam_client.sha256
    service_exe_path = [string]$review.manifest.target.service_exe.path
    service_exe_sha256 = [string]$review.manifest.target.service_exe.sha256
    service_dll_path = [string]$review.manifest.target.service_dll.path
    service_dll_sha256 = [string]$review.manifest.target.service_dll.sha256
    steam_exe_path = [string]$review.manifest.target.steam_exe.path
    steam_exe_sha256 = [string]$review.manifest.target.steam_exe.sha256
    steam_webhelper_path = [string]$review.manifest.target.steam_webhelper.path
    steam_webhelper_sha256 = [string]$review.manifest.target.steam_webhelper.sha256
    runprocess_log_path = $review.runprocess_log_path
    no_whitelist_output = $review.no_whitelist_output
    relocated_output = $review.relocated_output
    interactive_cmd_path = $review.interactive_cmd_path
    interactive_cmd_sha256 = $review.interactive_cmd_sha256
    interactive_cmd_desktop = $review.interactive_cmd_desktop
    interactive_cmd_timeout_milliseconds = $review.interactive_cmd_timeout_milliseconds
}
$record = [ordered]@{
    schema = 'steam-service-host-local-sequence/v1'
    run_id = $review.manifest.run_id
    started_at_utc = [DateTime]::UtcNow.ToString('o')
    active_requested = $true
    active_ipc_sent = $false
    game_launch_requested = $false
    evidence_mode = $review.evidence_mode
    service_mutated = $false
    status = 'inconclusive'
    manifest_sha256 = $review.manifest_sha256
    marker_sha256 = $review.marker_sha256
    controller_sha256 = $review.controller_sha256
    frame_module_sha256 = $review.frame_module_sha256
    allowed_case_order = @($review.manifest.active_policy.allowed_case_order)
    fixtures = $review.fixtures
    preflight = $null
    cases = [ordered]@{}
    sentinel = $null
    service_after = $null
    steam_files_unchanged = $null
    no_game_gate_after = $null
    error = $null
    receipt_path = $null
    receipt_sha256_path = $null
    journal_path = $null
    journal_sha256 = $null
    sidecar_path = $null
    sidecar_sha256 = $null
    receipt_write_attempted = $false
    evidence_write_error = $null
}
$journalPath = Join-Path $review.evidence_directory 'host-local-sequence-journal.jsonl'
$receiptPath = Join-Path $review.evidence_directory 'host-local-sequence.json'
$receiptHashPath = Join-Path $review.evidence_directory 'host-local-sequence.sha256'
$sidecarPath = Join-Path $review.evidence_directory 'host-local-sequence-sidecar.json'
$journal = $null
$receipt = $null
$beforeHashes = $null
$servicePid = [uint32]0
$steamClientPid = [uint32]0
try {
    $journal = Open-HostEvidenceStream $journalPath
    $receipt = Open-HostEvidenceStream $receiptPath
    Write-HostJournal $journal 'active-admitted' ([ordered]@{
        manifest_sha256 = $record.manifest_sha256
        marker_sha256 = $record.marker_sha256
        controller_sha256 = $record.controller_sha256
        frame_module_sha256 = $record.frame_module_sha256
        case_order = $record.allowed_case_order
    })
    $null = Initialize-HostNative
    $record.preflight = Get-HostActivePreflight $expected BothAbsent
    Write-HostJournal $journal 'preflight-passed' $record.preflight
    $servicePid = [uint32]$record.preflight.service.process_id
    $steamClientPid = [uint32]$record.preflight.no_game_gate.steam_client_process_id
    $beforeHashes = @($record.preflight.binaries | ForEach-Object { $_.sha256 })
    $revalidateBothAbsent = {
        param($peerPid)
        $now = Get-HostActivePreflight $expected BothAbsent
        if ($now.service.process_id -ne $servicePid -or $peerPid -ne $servicePid) { throw 'Steam Client Service PID changed before request write.' }
        if ($now.no_game_gate.steam_client_process_id -ne $steamClientPid) { throw 'Steam Client PID changed before request write.' }
    }

    $negative = Invoke-HostIpcRequest -Operation Whitelist -Frame $review.frames.negative_whitelist -Timeout $TimeoutMilliseconds -Revalidate $revalidateBothAbsent
    $record.active_ipc_sent = $record.active_ipc_sent -or $negative.request_bytes_written -gt 0
    Assert-HostTransport $negative 'signature-negative'
    $record.cases['signature-negative'] = [ordered]@{ transport = $negative; expected_rejection = $negative.response_value -eq -1 }
    Write-HostJournal $journal 'signature-negative' $record.cases['signature-negative']
    if (-not $record.cases['signature-negative'].expected_rejection) { throw 'Signature-negative whitelist control was not rejected with -1.' }

    $positive = Invoke-HostIpcRequest -Operation Whitelist -Frame $review.frames.positive_whitelist -Timeout $TimeoutMilliseconds -Revalidate $revalidateBothAbsent
    $record.active_ipc_sent = $record.active_ipc_sent -or $positive.request_bytes_written -gt 0
    Assert-HostTransport $positive 'signed-whitelist-positive'
    $record.cases['signed-whitelist-positive'] = [ordered]@{ transport = $positive; expected_acceptance = $positive.response_value -eq 0 }
    Write-HostJournal $journal 'signed-whitelist-positive' $record.cases['signed-whitelist-positive']
    if (-not $record.cases['signed-whitelist-positive'].expected_acceptance) { throw 'Exact signed whitelist control did not return 0.' }

    $relocated = Invoke-HostIpcRequest -Operation Run -Frame $review.frames.relocated_run -Timeout $TimeoutMilliseconds -Revalidate $revalidateBothAbsent
    $record.active_ipc_sent = $record.active_ipc_sent -or $relocated.request_bytes_written -gt 0
    Assert-HostTransport $relocated 'relocated-chain-sentinel'
    $relocatedObservationMilliseconds = if ($review.evidence_mode -ceq 'interactive-system-cmd') {
        [int]$review.interactive_cmd_timeout_milliseconds
    } else {
        $RunObservationMilliseconds
    }
    $sentinelObserved = Wait-HostOutput $review.relocated_output $relocatedObservationMilliseconds
    if ($sentinelObserved) { Start-Sleep -Milliseconds 250 }
    $revalidateRelocatedMayExist = {
        param($peerPid)
        $now = Get-HostActivePreflight $expected RelocatedMayExist
        if ($now.service.process_id -ne $servicePid -or $peerPid -ne $servicePid) { throw 'Steam Client Service PID changed before post-run query.' }
        if ($now.no_game_gate.steam_client_process_id -ne $steamClientPid) { throw 'Steam Client PID changed before post-run query.' }
    }
    $relocatedQuery = Invoke-HostIpcRequest -Operation Query -Frame $review.frames.query -Timeout $TimeoutMilliseconds -Revalidate $revalidateRelocatedMayExist
    $record.active_ipc_sent = $record.active_ipc_sent -or $relocatedQuery.request_bytes_written -gt 0
    Assert-HostTransport $relocatedQuery 'relocated-run-query'
    $record.cases['relocated-chain-sentinel'] = [ordered]@{
        run_transport = $relocated
        query_transport = $relocatedQuery
        sentinel_observed = $sentinelObserved
        run_request_accepted = $relocated.response_value -eq $true
        terminal_success_observed = $relocatedQuery.response_value -eq 0
    }
    if ($sentinelObserved) {
        $sentinel = Get-Content -Raw -LiteralPath $review.relocated_output | ConvertFrom-Json
        $record.sentinel = $sentinel
        $expectedLauncher = Join-Path $review.relocated_root 'launcher.exe'
        $sentinelCommonValid = $sentinel.output_path -ceq $review.relocated_output -and
            $sentinel.run_directory -ceq [IO.Path]::GetDirectoryName($review.relocated_output) -and
            $sentinel.self_path -ceq $expectedLauncher -and
            $sentinel.self_sha256 -ieq [string]$review.manifest.sentinel.sha256 -and
            $sentinel.user_sid -ceq 'S-1-5-18' -and
            $sentinel.integrity_sid -ceq 'S-1-16-16384'
        if ($review.evidence_mode -ceq 'interactive-system-cmd') {
            $interactiveCmdValid = $sentinel.schema_version -eq 3 -and
                $sentinel.evidence_mode -ceq 'interactive-system-cmd' -and
                $sentinel.session_id -eq $review.expected_requester_session_id -and
                $sentinel.interactive_cmd_spawned -eq $true -and
                [uint32]$sentinel.child_process_id -gt 0 -and
                $sentinel.child_user_sid -ceq 'S-1-5-18' -and
                $sentinel.child_integrity_sid -ceq 'S-1-16-16384' -and
                $sentinel.child_integrity_rid -eq 16384 -and
                $sentinel.child_session_id -eq $review.expected_requester_session_id -and
                $sentinel.child_image_path -ieq $review.interactive_cmd_path -and
                $sentinel.child_image_sha256 -ieq $review.interactive_cmd_sha256 -and
                $sentinel.child_command_line -ceq ('"' + $sentinel.child_image_path + '" /D /Q') -and
                $sentinel.child_desktop -ceq $review.interactive_cmd_desktop -and
                [uint32]$sentinel.child_creation_flags -eq 20 -and
                $sentinel.child_job_assigned -eq $true -and
                $sentinel.child_job_kill_on_close -eq $true -and
                $sentinel.child_exit_observed -eq $true -and
                [uint32]$sentinel.child_exit_code -ne 259 -and
                $sentinel.child_cleanup_confirmed -eq $true -and
                $sentinel.lifetime_policy -ceq 'until-user-exit' -and
                [uint32]$sentinel.timeout_milliseconds -eq $review.interactive_cmd_timeout_milliseconds -and
                $sentinel.child_terminated_by_timeout -eq $false
            $sentinelValid = $sentinelCommonValid -and $interactiveCmdValid
            $record.cases['relocated-chain-sentinel'].interactive_cmd_valid = $interactiveCmdValid
        } else {
            $sentinelValid = $sentinelCommonValid -and $sentinel.schema_version -eq 2
            $record.cases['relocated-chain-sentinel'].interactive_cmd_valid = $false
        }
        $record.cases['relocated-chain-sentinel'].sentinel_valid = $sentinelValid
        $record.cases['relocated-chain-sentinel'].system_impact_confirmed = $sentinelValid
    } else {
        $record.cases['relocated-chain-sentinel'].sentinel_valid = $false
        $record.cases['relocated-chain-sentinel'].system_impact_confirmed = $false
    }
    Write-HostJournal $journal 'relocated-chain-sentinel' $record.cases['relocated-chain-sentinel']
    if (-not $record.cases['relocated-chain-sentinel'].run_request_accepted -or
        -not $record.cases['relocated-chain-sentinel'].terminal_success_observed -or
        -not $record.cases['relocated-chain-sentinel'].system_impact_confirmed) {
        throw 'Relocated chain did not produce the complete SYSTEM sentinel result.'
    }

    $baseline = Invoke-HostIpcRequest -Operation Query -Frame $review.frames.query -Timeout $TimeoutMilliseconds -Revalidate $revalidateRelocatedMayExist
    $record.active_ipc_sent = $record.active_ipc_sent -or $baseline.request_bytes_written -gt 0
    Assert-HostTransport $baseline 'pre-no-whitelist-baseline'
    $record.cases['pre-no-whitelist-baseline'] = [ordered]@{
        transport = $baseline
        expected_zero = $baseline.response_value -eq 0
        no_whitelist_sentinel_absent = -not (Test-Path -LiteralPath $review.no_whitelist_output)
    }
    Write-HostJournal $journal 'pre-no-whitelist-baseline' $record.cases['pre-no-whitelist-baseline']
    if (-not $record.cases['pre-no-whitelist-baseline'].expected_zero -or
        -not $record.cases['pre-no-whitelist-baseline'].no_whitelist_sentinel_absent) {
        throw 'Fresh no-whitelist baseline was not exactly zero with an absent sentinel.'
    }

    $noWhitelistLogBeforeExists = Test-Path -LiteralPath $expected.runprocess_log_path -PathType Leaf
    $noWhitelistLogBefore = Read-HostSharedFileBytes $expected.runprocess_log_path -AllowMissingLeaf
    $noWhitelist = Invoke-HostIpcRequest -Operation Run -Frame $review.frames.no_whitelist_run -Timeout $TimeoutMilliseconds -Revalidate $revalidateRelocatedMayExist
    $record.active_ipc_sent = $record.active_ipc_sent -or $noWhitelist.request_bytes_written -gt 0
    Assert-HostTransport $noWhitelist 'no-whitelist-negative'
    $noWhitelistObserved = Wait-HostOutput $review.no_whitelist_output $RunObservationMilliseconds
    $noWhitelistQuery = Invoke-HostIpcRequest -Operation Query -Frame $review.frames.query -Timeout $TimeoutMilliseconds -Revalidate $revalidateRelocatedMayExist
    $record.active_ipc_sent = $record.active_ipc_sent -or $noWhitelistQuery.request_bytes_written -gt 0
    Assert-HostTransport $noWhitelistQuery 'no-whitelist-query'
    $noWhitelistLog = Get-HostAppendedRunProcessLogRecord `
        -Path $expected.runprocess_log_path `
        -BeforeBytes $noWhitelistLogBefore `
        -AppId ([uint32]$review.manifest.run.app_id) `
        -ExpectedLauncherPath ([string]$review.manifest.run.no_whitelist.process_decoded) `
        -BeforeExists $noWhitelistLogBeforeExists
    $noWhitelistFinalAbsent = -not (Test-Path -LiteralPath $review.no_whitelist_output)
    $baselineToRunMilliseconds = ([DateTimeOffset]::Parse($noWhitelist.request_written_at_utc) -
        [DateTimeOffset]::Parse($baseline.finished_at_utc)).TotalMilliseconds
    $record.cases['no-whitelist-negative'] = [ordered]@{
        baseline_query_value = $baseline.response_value
        baseline_to_run_write_milliseconds = $baselineToRunMilliseconds
        observation_milliseconds = $RunObservationMilliseconds
        run_transport = $noWhitelist
        query_transport = $noWhitelistQuery
        query_unchanged_from_baseline = $noWhitelistQuery.response_value -eq $baseline.response_value
        runprocess_log = $noWhitelistLog
        sentinel_observed = $noWhitelistObserved
        sentinel_absent_after_query = $noWhitelistFinalAbsent
        expected_differential = $noWhitelist.response_value -eq $true -and
            -not $noWhitelistObserved -and
            $noWhitelistFinalAbsent -and
            $noWhitelistLog.expected_rejection_log_observed -and
            $baselineToRunMilliseconds -ge 0
    }
    Write-HostJournal $journal 'no-whitelist-negative' $record.cases['no-whitelist-negative']
    if (-not $record.cases['no-whitelist-negative'].expected_differential) {
        throw 'No-whitelist negative did not produce the expected log-backed rejection with an absent sentinel.'
    }
    $record.status = 'system-impact-confirmed'
} catch {
    $record.error = $_.Exception.Message
    $record.status = if ($record.active_ipc_sent) { 'inconclusive-after-write' } else { 'blocked-before-write' }
    if ($null -ne $journal) { Write-HostJournal $journal 'error' ([ordered]@{ message = $record.error; status = $record.status }) }
} finally {
    try { $record.service_after = Get-HostServiceRecord } catch { $record.service_after = [ordered]@{ error = $_.Exception.Message } }
    try {
        $record.no_game_gate_after = Test-NoGameProcessGate `
            -ExpectedSteamExePath $expected.steam_exe_path `
            -ExpectedSteamWebHelperPath $expected.steam_webhelper_path
    } catch { $record.no_game_gate_after = [ordered]@{ passed = $false; error = $_.Exception.Message } }
    try {
        $afterHashes = @(
            Get-HostControlSha256 $expected.steam_client_path
            Get-HostControlSha256 $expected.service_exe_path
            Get-HostControlSha256 $expected.service_dll_path
            Get-HostControlSha256 $expected.steam_exe_path
            Get-HostControlSha256 $expected.steam_webhelper_path
        )
        $record.steam_files_unchanged = $null -ne $beforeHashes -and (Test-ExactStringSet $afterHashes $beforeHashes)
    } catch { $record.steam_files_unchanged = $false }
    if ($record.status -ceq 'system-impact-confirmed' -and (
        -not $record.no_game_gate_after.passed -or
        -not $record.steam_files_unchanged -or
        $record.service_after.process_id -ne $servicePid -or
        $record.service_after.state -cne 'Running' -or
        $record.no_game_gate_after.steam_client_process_id -ne $steamClientPid
    )) {
        $record.status = 'inconclusive-after-write'
        $record.error = 'Post-sequence service, process, or immutable-file verification failed.'
    }
    $record.finished_at_utc = [DateTime]::UtcNow.ToString('o')
    try {
        $record.receipt_path = $receiptPath
        $record.journal_path = if (Test-Path -LiteralPath $journalPath) { $journalPath } else { $null }
        $record.receipt_sha256_path = $receiptHashPath
        $record.sidecar_path = $sidecarPath
        if ($null -ne $journal) {
            Write-HostJournal $journal 'terminal' ([ordered]@{
                status = $record.status
                active_ipc_sent = $record.active_ipc_sent
                error = $record.error
                no_game_gate_after = $record.no_game_gate_after
                steam_files_unchanged = $record.steam_files_unchanged
            })
            $journal.Dispose()
            $journal = $null
        }
        if (Test-Path -LiteralPath $journalPath) { $record.journal_sha256 = Get-HostControlSha256 $journalPath }
        if ($null -eq $receipt) { throw 'Primary receipt reservation is unavailable.' }
        $record.receipt_write_attempted = $true
        Write-HostJsonStream $receipt $record
        $receipt.Dispose()
        $receipt = $null
        $persistedReceipt = Get-Content -Raw -LiteralPath $receiptPath | ConvertFrom-Json
        if ($persistedReceipt.schema -cne $record.schema -or
            $persistedReceipt.run_id -cne $record.run_id -or
            $persistedReceipt.status -cne $record.status -or
            $persistedReceipt.journal_sha256 -cne $record.journal_sha256) {
            throw 'Primary receipt readback mismatch.'
        }
        $receiptHash = Get-HostControlSha256 $receiptPath
        Write-HostNewText $receiptHashPath ($receiptHash + '  ' + [IO.Path]::GetFileName($receiptPath) + "`n")
        $sidecar = [ordered]@{
            schema = 'steam-service-host-local-sequence-sidecar/v1'
            run_id = $record.run_id
            status = $record.status
            receipt = [ordered]@{
                path = $receiptPath
                length = (Get-Item -LiteralPath $receiptPath).Length
                sha256 = $receiptHash
                checksum_path = $receiptHashPath
            }
            journal = [ordered]@{
                path = $journalPath
                length = (Get-Item -LiteralPath $journalPath).Length
                sha256 = $record.journal_sha256
            }
            manifest = [ordered]@{ path = $review.manifest_path; sha256 = $record.manifest_sha256 }
            marker = [ordered]@{ path = $review.marker_path; sha256 = $record.marker_sha256 }
            controller_sha256 = $record.controller_sha256
            frame_module_sha256 = $record.frame_module_sha256
            case_order = $record.allowed_case_order
            active_ipc_sent = $record.active_ipc_sent
            no_game_gate_before = if ($null -ne $record.preflight) { $record.preflight.no_game_gate.passed } else { $false }
            no_game_gate_after = $record.no_game_gate_after.passed
            sentinel_valid = if ($record.cases.Contains('relocated-chain-sentinel')) {
                $record.cases['relocated-chain-sentinel'].sentinel_valid
            } else { $false }
            sidecar_write_attempted = $true
        }
        Write-HostNewJson $sidecarPath $sidecar
        $persistedSidecar = Get-Content -Raw -LiteralPath $sidecarPath | ConvertFrom-Json
        if ($persistedSidecar.schema -cne $sidecar.schema -or
            $persistedSidecar.receipt.sha256 -cne $receiptHash -or
            $persistedSidecar.journal.sha256 -cne $record.journal_sha256) {
            throw 'Evidence sidecar readback mismatch.'
        }
        $record['receipt_sha256'] = $receiptHash
        $record.sidecar_sha256 = Get-HostControlSha256 $sidecarPath
    } catch { $record.evidence_write_error = $_.Exception.Message }
    if ($null -ne $journal) { $journal.Dispose() }
    if ($null -ne $receipt) { $receipt.Dispose() }
}

[pscustomobject]$record
