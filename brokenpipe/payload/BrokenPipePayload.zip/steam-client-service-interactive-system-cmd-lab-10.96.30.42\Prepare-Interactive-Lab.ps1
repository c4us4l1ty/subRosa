[CmdletBinding()]
param(
    [ValidateNotNullOrEmpty()]
    [string]$RuntimeRoot = 'C:\Users\Public\SteamServiceInteractiveCmdLab'
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$expected = [ordered]@{
    file_version = '10.96.30.42'
    signed_vdf = 'F7B104EBEB44F7B305FF0F02F8D06EFA461914D09187731EA7B1400D3198710C'
    interactive_demo = 'DF0CAFD4B99BFBB4C3DCA44CF198B2E78E54B50FFA389AC21BC0B5D53AFA8EE8'
    packer = '3D9DFB55C15DA3C8953C08D6917DBBE7A67BD8F3EC57954067C54A63739173D6'
    controller = '51E379DEE8A5A29231304D223BFD166213309E822E057A5CA6692293C1D6086A'
    frames = '6E5EA7DA1F48103B2A54F93220B98F407419EC9C0F4A2E2F680B975954F97944'
}

function Get-PocSha256 {
    param([Parameter(Mandatory)][string]$Path)
    (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToUpperInvariant()
}

function Get-PocFixedPath {
    param([Parameter(Mandatory)][string]$Path)
    if ($Path -notmatch '^[A-Za-z]:\\' -or $Path.Contains('/') -or $Path.IndexOf(':', 2) -ge 0) {
        throw "Path must use a local drive-letter form: $Path"
    }
    $full = [IO.Path]::GetFullPath($Path)
    $drive = [IO.Path]::GetPathRoot($full)
    if ([IO.DriveInfo]::new($drive).DriveType -ne [IO.DriveType]::Fixed) {
        throw "Path must be on a fixed local volume: $Path"
    }
    if ($full -ceq $drive) { throw 'Runtime root cannot be a drive root.' }
    $full.TrimEnd('\')
}

function Assert-PocNoReparse {
    param([Parameter(Mandatory)][string]$Path, [switch]$AllowMissingTail)
    $full = Get-PocFixedPath $Path
    $drive = [IO.Path]::GetPathRoot($full)
    $parts = @($full.Substring($drive.Length).Split('\', [StringSplitOptions]::RemoveEmptyEntries))
    $current = $drive
    for ($index = 0; $index -lt $parts.Count; $index++) {
        $current = Join-Path $current $parts[$index]
        if (-not (Test-Path -LiteralPath $current)) {
            if ($AllowMissingTail) { return $full }
            throw "Missing path component: $current"
        }
        $item = Get-Item -LiteralPath $current -Force
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw "Reparse-point path is not allowed: $current"
        }
    }
    $full
}

function Assert-PocHash {
    param([Parameter(Mandatory)][string]$Path, [Parameter(Mandatory)][string]$Sha256)
    $full = Assert-PocNoReparse $Path
    if (-not (Test-Path -LiteralPath $full -PathType Leaf)) { throw "Required file is missing: $full" }
    if ((Get-PocSha256 $full) -cne $Sha256) { throw "SHA-256 mismatch: $full" }
    $full
}

function Write-PocNewJson {
    param([Parameter(Mandatory)][string]$Path, [Parameter(Mandatory)]$Value)
    $bytes = [Text.UTF8Encoding]::new($false).GetBytes(($Value | ConvertTo-Json -Depth 10))
    $stream = [IO.File]::Open($Path, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
    try {
        $stream.Write($bytes, 0, $bytes.Length)
        $stream.Flush($true)
    } finally {
        $stream.Dispose()
    }
}

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = [Security.Principal.WindowsPrincipal]::new($identity)
if ($principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run preparation from a normal non-administrator PowerShell window.'
}
$whoamiPath = Join-Path $env:SystemRoot 'System32\whoami.exe'
$tokenGroups = @(& $whoamiPath /groups /fo csv /nh 2>&1)
if ($LASTEXITCODE -ne 0) { throw 'Could not inspect the current token groups.' }
$tokenGroupText = $tokenGroups -join "`n"
if (-not $tokenGroupText.Contains('S-1-16-8192')) {
    throw 'Requester token is not medium integrity.'
}
if ($tokenGroupText.Contains('S-1-5-32-544')) {
    throw 'Requester token belongs to the local Administrators group. Use a standard Windows user.'
}

$packageRoot = Assert-PocNoReparse $PSScriptRoot
$signedVdf = Assert-PocHash (Join-Path $packageRoot 'assets\signed-installscript.vdf') $expected.signed_vdf
$evidenceMode = 'interactive-system-cmd'
$sentinelName = 'steam_service_interactive_demo.exe'
$sentinelExpected = $expected.interactive_demo
$sentinel = Assert-PocHash (Join-Path $packageRoot ('assets\' + $sentinelName)) $sentinelExpected
$packer = Assert-PocHash (Join-Path $packageRoot 'lib\steam_service_host_local_pack.ps1') $expected.packer
$controllerSource = Assert-PocHash (Join-Path $packageRoot 'lib\steam_service_host_local_control.ps1') $expected.controller
$framesSource = Assert-PocHash (Join-Path $packageRoot 'lib\steam_service_ipc_frames.ps1') $expected.frames

$runtimeFull = Assert-PocNoReparse -Path $RuntimeRoot -AllowMissingTail
[void][IO.Directory]::CreateDirectory($runtimeFull)
$runtimeFull = Assert-PocNoReparse $runtimeFull
$runsRoot = Join-Path $runtimeFull 'runs'
$scratchRoot = Join-Path $runtimeFull 'scratch'
$receiptsRoot = Join-Path $runtimeFull 'receipts'
foreach ($directory in @($runsRoot, $scratchRoot, $receiptsRoot)) {
    [void][IO.Directory]::CreateDirectory($directory)
    $null = Assert-PocNoReparse $directory
}

$runId = 'h1-' + [DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss') + '-' + [Guid]::NewGuid().ToString('N').Substring(0, 8)
$scratchRunRoot = Join-Path $scratchRoot $runId
$runRoot = Join-Path $runsRoot $runId
$runtimePackRoot = Join-Path $runRoot 'host-local-pack'
$runtimeController = Join-Path $runRoot 'steam_service_host_local_control.ps1'
$runtimeFrames = Join-Path $runRoot 'steam_service_ipc_frames.ps1'
$prepareReceiptPath = Join-Path $receiptsRoot ($runId + '-prepare-result.json')
foreach ($path in @($scratchRunRoot, $runRoot, $prepareReceiptPath)) {
    if (Test-Path -LiteralPath $path) { throw "One-use output already exists: $path" }
}

$requesterSessionId = [uint32][Diagnostics.Process]::GetCurrentProcess().SessionId
if ($requesterSessionId -eq 0) { throw 'Interactive demo requires a logged-in user session.' }
$packArguments = @{
    SignedVdfPath = $signedVdf
    ExpectedSignedVdfSha256 = $expected.signed_vdf
    SentinelPath = $sentinel
    ExpectedSentinelSha256 = $sentinelExpected
    OutputRoot = $scratchRoot
    RunId = $runId
    ControllerPath = $controllerSource
    FrameModulePath = $framesSource
    ControllerRuntimePath = $runtimeController
    FrameModuleRuntimePath = $runtimeFrames
    PackRuntimeRoot = $runtimePackRoot
    ExpectedRequesterIdentity = $identity.Name
    ExpectedRequesterSid = $identity.User.Value
    EvidenceMode = $evidenceMode
    ExpectedRequesterSessionId = $requesterSessionId
}
$pack = & $packer @packArguments

$expectedPackSchema = 'steam-service-host-local-pack-result/v3'
if ($null -eq $pack -or $pack.schema -cne $expectedPackSchema -or
    $pack.active_ipc_allowed -ne $true -or $pack.game_launch_permitted -ne $false) {
    throw 'Pack preparation did not return the expected inert result.'
}

[void][IO.Directory]::CreateDirectory($runRoot)
[void][IO.Directory]::CreateDirectory($runtimePackRoot)
Copy-Item -LiteralPath $controllerSource -Destination $runtimeController
Copy-Item -LiteralPath $framesSource -Destination $runtimeFrames
foreach ($item in @(Get-ChildItem -LiteralPath $pack.pack_root -Force)) {
    Copy-Item -LiteralPath $item.FullName -Destination $runtimePackRoot -Recurse
}

$runtimeController = Assert-PocHash $runtimeController $expected.controller
$runtimeFrames = Assert-PocHash $runtimeFrames $expected.frames
$runtimeManifest = Assert-PocNoReparse (Join-Path $runtimePackRoot 'manifest.json')
$runtimeMarker = Assert-PocNoReparse (Join-Path $runtimePackRoot 'marker.json')
$plan = & $runtimeController -ManifestPath $runtimeManifest
if ($null -eq $plan -or
    $plan.schema -cne 'steam-service-host-local-control-plan/v1' -or
    $plan.status -cne 'reviewed-no-ipc' -or
    $plan.active_requested -ne $false -or
    $plan.active_ipc_sent -ne $false -or
    $plan.service_mutated -ne $false -or
    $plan.game_launch_requested -ne $false -or
    $plan.evidence_mode -cne $evidenceMode -or
    $plan.manifest_sha256 -cne (Get-PocSha256 $runtimeManifest) -or
    $plan.marker_sha256 -cne (Get-PocSha256 $runtimeMarker) -or
    $plan.controller_sha256 -cne $expected.controller -or
    $plan.frame_module_sha256 -cne $expected.frames) {
    throw 'Prepared run failed the no-IPC plan review.'
}

$manifest = Get-Content -LiteralPath $runtimeManifest -Raw | ConvertFrom-Json
$observedVersions = [ordered]@{}
foreach ($targetName in @('steam_client', 'service_exe', 'service_dll', 'steam_exe', 'steam_webhelper')) {
    $target = $manifest.target.$targetName
    $version = (Get-Item -LiteralPath ([string]$target.path) -Force).VersionInfo.FileVersion
    if ($version -cne $expected.file_version) {
        throw "Unexpected file version for $targetName. Expected $($expected.file_version), observed $version."
    }
    $observedVersions[$targetName] = $version
}
$receipt = [ordered]@{
    schema = 'steam-service-interactive-cmd-lab-prepare/v1'
    prepared_at_utc = [DateTime]::UtcNow.ToString('o')
    prepared = $true
    run_id = $runId
    package_root = $packageRoot
    runtime_root = $runtimeFull
    run_root = $runRoot
    pack_root = $runtimePackRoot
    manifest_path = $runtimeManifest
    manifest_sha256 = $plan.manifest_sha256
    marker_path = $runtimeMarker
    marker_sha256 = $plan.marker_sha256
    controller_path = $runtimeController
    controller_sha256 = $plan.controller_sha256
    frame_module_path = $runtimeFrames
    frame_module_sha256 = $plan.frame_module_sha256
    evidence_mode = $evidenceMode
    interactive_system_cmd = $true
    requester = [ordered]@{
        identity = $identity.Name
        sid = $identity.User.Value
        integrity_sid = 'S-1-16-8192'
        session_id = [uint32][Diagnostics.Process]::GetCurrentProcess().SessionId
    }
    tested_file_version = $expected.file_version
    observed_file_versions = $observedVersions
    target = $manifest.target
    plan_status = $plan.status
    active_ipc_sent = $false
    service_mutated = $false
    game_launch_requested = $false
}
Write-PocNewJson $prepareReceiptPath $receipt

Write-Output "BROKENPIPE_RUN_ID=$runId"
