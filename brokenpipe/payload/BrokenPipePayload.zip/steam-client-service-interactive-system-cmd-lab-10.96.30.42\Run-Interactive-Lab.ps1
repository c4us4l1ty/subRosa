[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [ValidatePattern('^[a-z0-9][a-z0-9-]{2,63}$')]
    [string]$RunId,

    [ValidateNotNullOrEmpty()]
    [string]$RuntimeRoot = 'C:\Users\Public\SteamServiceInteractiveCmdLab'
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Get-PocSha256 {
    param([Parameter(Mandatory)][string]$Path)
    (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToUpperInvariant()
}

function Get-PocFixedPath {
    param([Parameter(Mandatory)][string]$Path)
    if ($Path -notmatch '^[A-Za-z]:\\' -or $Path.Contains('/') -or $Path.IndexOf(':', 2) -ge 0) {
        throw "Path must use a local drive-letter form: $Path"
    }
    $full = [IO.Path]::GetFullPath($Path)
    $drive = [IO.Path]::GetPathRoot($full)
    if ([IO.DriveInfo]::new($drive).DriveType -ne [IO.DriveType]::Fixed) {
        throw "Path must be on a fixed local volume: $Path"
    }
    if ($full -ceq $drive) { throw 'Runtime root cannot be a drive root.' }
    $full.TrimEnd('\')
}

function Assert-PocNoReparse {
    param([Parameter(Mandatory)][string]$Path)
    $full = Get-PocFixedPath $Path
    $drive = [IO.Path]::GetPathRoot($full)
    $parts = @($full.Substring($drive.Length).Split('\', [StringSplitOptions]::RemoveEmptyEntries))
    $current = $drive
    foreach ($part in $parts) {
        $current = Join-Path $current $part
        if (-not (Test-Path -LiteralPath $current)) { throw "Missing path component: $current" }
        $item = Get-Item -LiteralPath $current -Force
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw "Reparse-point path is not allowed: $current"
        }
    }
    $full
}

function Assert-PocHash {
    param([Parameter(Mandatory)][string]$Path, [Parameter(Mandatory)][string]$Sha256)
    $full = Assert-PocNoReparse $Path
    if (-not (Test-Path -LiteralPath $full -PathType Leaf)) { throw "Required file is missing: $full" }
    if ((Get-PocSha256 $full) -cne $Sha256.ToUpperInvariant()) { throw "SHA-256 mismatch: $full" }
    $full
}

function Write-PocNewJson {
    param([Parameter(Mandatory)][string]$Path, [Parameter(Mandatory)]$Value)
    $bytes = [Text.UTF8Encoding]::new($false).GetBytes(($Value | ConvertTo-Json -Depth 10))
    $stream = [IO.File]::Open($Path, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
    try {
        $stream.Write($bytes, 0, $bytes.Length)
        $stream.Flush($true)
    } finally {
        $stream.Dispose()
    }
}

function Get-PocOptionalProperty {
    param([Parameter(Mandatory)]$Value, [Parameter(Mandatory)][string]$Name)
    $property = $Value.PSObject.Properties[$Name]
    if ($null -eq $property) { return $null }
    $property.Value
}

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = [Security.Principal.WindowsPrincipal]::new($identity)
if ($principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run the PoC from a normal non-administrator PowerShell window.'
}
$whoamiPath = Join-Path $env:SystemRoot 'System32\whoami.exe'
$tokenGroups = @(& $whoamiPath /groups /fo csv /nh 2>&1)
if ($LASTEXITCODE -ne 0) { throw 'Could not inspect the current token groups.' }
$tokenGroupText = $tokenGroups -join "`n"
if (-not $tokenGroupText.Contains('S-1-16-8192') -or $tokenGroupText.Contains('S-1-5-32-544')) {
    throw 'Use a standard Windows user with a medium-integrity token.'
}

$runtimeFull = Assert-PocNoReparse $RuntimeRoot
$runRoot = Assert-PocNoReparse (Join-Path $runtimeFull "runs\$RunId")
$packRoot = Assert-PocNoReparse (Join-Path $runRoot 'host-local-pack')
$receiptsRoot = Assert-PocNoReparse (Join-Path $runtimeFull 'receipts')
$prepareReceiptPath = Assert-PocNoReparse (Join-Path $receiptsRoot ($RunId + '-prepare-result.json'))
$summaryPath = Join-Path $receiptsRoot ($RunId + '-run-summary.json')
if (Test-Path -LiteralPath $summaryPath) { throw 'This run ID already has a run summary and must not be reused.' }

$prepare = Get-Content -LiteralPath $prepareReceiptPath -Raw | ConvertFrom-Json
$expectedEvidenceMode = 'interactive-system-cmd'
$controller = Assert-PocHash (Join-Path $runRoot 'steam_service_host_local_control.ps1') ([string]$prepare.controller_sha256)
$frames = Assert-PocHash (Join-Path $runRoot 'steam_service_ipc_frames.ps1') ([string]$prepare.frame_module_sha256)
$manifestPath = Assert-PocHash (Join-Path $packRoot 'manifest.json') ([string]$prepare.manifest_sha256)
$markerPath = Assert-PocHash (Join-Path $packRoot 'marker.json') ([string]$prepare.marker_sha256)
if ($prepare.schema -cne 'steam-service-interactive-cmd-lab-prepare/v1' -or
    $prepare.prepared -ne $true -or
    $prepare.run_id -cne $RunId -or
    $prepare.run_root -cne $runRoot -or
    $prepare.pack_root -cne $packRoot -or
    $prepare.manifest_path -cne $manifestPath -or
    $prepare.marker_path -cne $markerPath -or
    $prepare.controller_path -cne $controller -or
    $prepare.frame_module_path -cne $frames -or
    $prepare.requester.identity -cne $identity.Name -or
    $prepare.requester.sid -cne $identity.User.Value -or
    $prepare.requester.integrity_sid -cne 'S-1-16-8192' -or
    [uint32]$prepare.requester.session_id -ne [uint32][Diagnostics.Process]::GetCurrentProcess().SessionId -or
    $prepare.evidence_mode -cne $expectedEvidenceMode -or
    $prepare.interactive_system_cmd -ne $true -or
    $prepare.tested_file_version -cne '10.96.30.42' -or
    $prepare.plan_status -cne 'reviewed-no-ipc' -or
    $prepare.active_ipc_sent -ne $false -or
    $prepare.service_mutated -ne $false -or
    $prepare.game_launch_requested -ne $false) {
    throw 'Preparation receipt binding is invalid.'
}

$plan = & $controller -ManifestPath $manifestPath
if ($null -eq $plan -or
    $plan.schema -cne 'steam-service-host-local-control-plan/v1' -or
    $plan.status -cne 'reviewed-no-ipc' -or
    $plan.active_ipc_sent -ne $false -or
    $plan.service_mutated -ne $false -or
    $plan.game_launch_requested -ne $false -or
    $plan.evidence_mode -cne $expectedEvidenceMode -or
    $plan.manifest_sha256 -cne $prepare.manifest_sha256 -or
    $plan.marker_sha256 -cne $prepare.marker_sha256 -or
    $plan.controller_sha256 -cne $prepare.controller_sha256 -or
    $plan.frame_module_sha256 -cne $prepare.frame_module_sha256) {
    throw 'Final no-IPC plan review failed.'
}

$manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
foreach ($target in @(
    $manifest.target.steam_client,
    $manifest.target.service_exe,
    $manifest.target.service_dll,
    $manifest.target.steam_exe,
    $manifest.target.steam_webhelper
)) {
    $null = Assert-PocHash ([string]$target.path) ([string]$target.sha256)
    $observedVersion = (Get-Item -LiteralPath ([string]$target.path) -Force).VersionInfo.FileVersion
    if ($observedVersion -cne [string]$prepare.tested_file_version) {
        throw "Steam file version changed after preparation: $($target.path)"
    }
}

$service = Get-CimInstance Win32_Service -Filter "Name='Steam Client Service'" -ErrorAction Stop
if ($null -eq $service -or $service.State -cne 'Running' -or [uint32]$service.ProcessId -eq 0 -or
    $service.StartName -cne 'LocalSystem') {
    throw 'Steam Client Service must already be running as LocalSystem. Start Steam normally and wait.'
}
$processes = @(Get-CimInstance Win32_Process -ErrorAction Stop)
$steamClient = @($processes | Where-Object {
    $_.Name -ieq 'steam.exe' -and [string]$_.ExecutablePath -ieq [string]$manifest.target.steam_exe.path
})
$steamWebHelpers = @($processes | Where-Object {
    $_.Name -ieq 'steamwebhelper.exe' -and [string]$_.ExecutablePath -ieq [string]$manifest.target.steam_webhelper.path
})
$gameProcesses = @($processes | Where-Object {
    $name = [IO.Path]::GetFileNameWithoutExtension([string]$_.Name)
    $path = [string]$_.ExecutablePath
    $name -imatch '^(cs2|hl2|dota2|gameoverlayui|wallpaper32|wallpaper64|wallpaper|ui32|webwallpaper32)$' -or
        (-not [string]::IsNullOrWhiteSpace($path) -and $path -imatch '\\steamapps\\common\\')
})
if ($steamClient.Count -ne 1 -or $steamWebHelpers.Count -lt 1 -or $gameProcesses.Count -ne 0) {
    throw 'Steam must be open and idle with no game or Steam application process running.'
}

$confirmation = Read-Host
if ($confirmation -cne 'INTERACTIVE SYSTEM CMD') {
    return
}

$result = $null
$expectedEvidenceRoot = Join-Path $packRoot 'evidence'
$expectedSequenceReceipt = Join-Path $expectedEvidenceRoot 'host-local-sequence.json'
$expectedJournal = Join-Path $expectedEvidenceRoot 'host-local-sequence-journal.jsonl'
$expectedSidecar = Join-Path $expectedEvidenceRoot 'host-local-sequence-sidecar.json'
try {
    $result = & $controller `
        -ManifestPath $manifestPath `
        -ExpectedManifestSha256 ([string]$plan.manifest_sha256) `
        -ExpectedMarkerSha256 ([string]$plan.marker_sha256) `
        -ExpectedControllerSha256 ([string]$plan.controller_sha256) `
        -ExpectedFrameModuleSha256 ([string]$plan.frame_module_sha256) `
        -Active `
        -AcknowledgeHostLocalRisk
} catch {
    $failure = [ordered]@{
        schema = 'steam-service-interactive-cmd-lab-run-summary/v1'
        captured_at_utc = [DateTime]::UtcNow.ToString('o')
        run_id = $RunId
        passed = $false
        controller_status = 'wrapper-exception'
        active_ipc_sent = $null
        evidence_directory = $expectedEvidenceRoot
        sequence_receipt_path = if (Test-Path -LiteralPath $expectedSequenceReceipt) { $expectedSequenceReceipt } else { $null }
        journal_path = if (Test-Path -LiteralPath $expectedJournal) { $expectedJournal } else { $null }
        sidecar_path = if (Test-Path -LiteralPath $expectedSidecar) { $expectedSidecar } else { $null }
        error = $_.Exception.Message
    }
    try { Write-PocNewJson $summaryPath $failure } catch { }
    throw
}

if ($null -eq $result -or
    $result.schema -cne 'steam-service-host-local-sequence/v1' -or
    $result.status -cne 'system-impact-confirmed') {
    $controllerStatus = if ($null -ne $result) { Get-PocOptionalProperty $result 'status' } else { $null }
    $activeIpcSent = if ($null -ne $result) { Get-PocOptionalProperty $result 'active_ipc_sent' } else { $null }
    $controllerError = if ($null -ne $result) { Get-PocOptionalProperty $result 'error' } else { 'Controller returned no result.' }
    $failure = [ordered]@{
        schema = 'steam-service-interactive-cmd-lab-run-summary/v1'
        captured_at_utc = [DateTime]::UtcNow.ToString('o')
        run_id = $RunId
        passed = $false
        controller_status = $controllerStatus
        active_ipc_sent = $activeIpcSent
        evidence_directory = $expectedEvidenceRoot
        sequence_receipt_path = if (Test-Path -LiteralPath $expectedSequenceReceipt) { $expectedSequenceReceipt } else { $null }
        journal_path = if (Test-Path -LiteralPath $expectedJournal) { $expectedJournal } else { $null }
        sidecar_path = if (Test-Path -LiteralPath $expectedSidecar) { $expectedSidecar } else { $null }
        error = $controllerError
    }
    Write-PocNewJson $summaryPath $failure
    throw 'The controller did not return a complete success result.'
}

$signatureNegative = $result.cases.'signature-negative'
$signedPositive = $result.cases.'signed-whitelist-positive'
$relocated = $result.cases.'relocated-chain-sentinel'
$noWhitelist = $result.cases.'no-whitelist-negative'
$passed = $result.schema -ceq 'steam-service-host-local-sequence/v1' -and
    $result.status -ceq 'system-impact-confirmed' -and
    $result.active_requested -eq $true -and
    $result.active_ipc_sent -eq $true -and
    $result.game_launch_requested -eq $false -and
    $result.evidence_mode -ceq $expectedEvidenceMode -and
    $result.service_mutated -eq $false -and
    $result.steam_files_unchanged -eq $true -and
    $result.preflight.no_game_gate.passed -eq $true -and
    $result.no_game_gate_after.passed -eq $true -and
    $signatureNegative.expected_rejection -eq $true -and
    $signedPositive.expected_acceptance -eq $true -and
    $relocated.sentinel_valid -eq $true -and
    $relocated.system_impact_confirmed -eq $true -and
    $noWhitelist.expected_differential -eq $true -and
    $noWhitelist.sentinel_absent_after_query -eq $true -and
    $noWhitelist.runprocess_log.expected_rejection_log_observed -eq $true -and
    $result.sentinel.user_sid -ceq 'S-1-5-18' -and
    $result.sentinel.integrity_sid -ceq 'S-1-16-16384'
$passed = $passed -and
    $relocated.interactive_cmd_valid -eq $true -and
    $result.sentinel.interactive_cmd_spawned -eq $true -and
    $result.sentinel.child_user_sid -ceq 'S-1-5-18' -and
    $result.sentinel.child_integrity_sid -ceq 'S-1-16-16384' -and
    [uint32]$result.sentinel.child_session_id -eq [uint32]$prepare.requester.session_id -and
    $result.sentinel.child_job_assigned -eq $true -and
    $result.sentinel.child_job_kill_on_close -eq $true -and
    $result.sentinel.child_exit_observed -eq $true -and
    $result.sentinel.child_cleanup_confirmed -eq $true -and
    $result.sentinel.lifetime_policy -ceq 'until-user-exit' -and
    [uint32]$result.sentinel.timeout_milliseconds -eq 0

$summary = [ordered]@{
    schema = 'steam-service-interactive-cmd-lab-run-summary/v1'
    captured_at_utc = [DateTime]::UtcNow.ToString('o')
    run_id = $RunId
    passed = $passed
    controller_status = $result.status
    evidence_mode = $expectedEvidenceMode
    active_ipc_sent = $result.active_ipc_sent
    requester = $result.preflight.requester
    service = $result.preflight.service
    sentinel = $result.sentinel
    controls = [ordered]@{
        modified_signature_rejected = [bool]$signatureNegative.expected_rejection
        genuine_signed_vdf_accepted = [bool]$signedPositive.expected_acceptance
        relocated_system_sentinel_valid = [bool]$relocated.sentinel_valid
        unwhitelisted_sentinel_absent = [bool]$noWhitelist.sentinel_absent_after_query
        rejection_log_observed = [bool]$noWhitelist.runprocess_log.expected_rejection_log_observed
        game_launched = $false
        steam_files_unchanged = [bool]$result.steam_files_unchanged
    }
    sequence_receipt_path = $result.receipt_path
    sequence_receipt_sha256 = Get-PocOptionalProperty $result 'receipt_sha256'
    journal_path = $result.journal_path
    journal_sha256 = $result.journal_sha256
    sidecar_path = $result.sidecar_path
    sidecar_sha256 = $result.sidecar_sha256
    error = $result.error
}
Write-PocNewJson $summaryPath $summary

if (-not $passed) {
    throw 'The complete positive and negative proof gates did not all pass.'
}
