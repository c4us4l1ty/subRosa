# Steam Client Service interactive SYSTEM cmd lab

This package is only for a disposable, offline Windows VM that you own. It is a visual follow-up to the already confirmed identity-sentinel PoC. It is not the package submitted to HackerOne.

The lab helper accepts no executable path and no command text. If Steam starts it with the vulnerable SYSTEM token in the signed-in standard user's session, it launches only the canonical `System32\cmd.exe` on `winsta0\default` in a new console. The helper verifies the SYSTEM SID, System integrity SID, session ID, child image path, and child image SHA-256.

The cmd window remains open until you type `exit` or close it. The cmd process and anything started from it are contained in a Windows job object. After the main prompt closes, the helper terminates any remaining descendants and confirms the complete process tree is gone before writing the receipt. It creates no service, task, startup entry, or other persistence.

The original PowerShell window waits while the temporary SYSTEM cmd is open. The final result appears only after you type `exit`, or after the timeout and cleanup finish.

## Run

1. Use a disposable VM snapshot with networking disconnected.
2. Sign in as a standard Windows user.
3. Start Steam normally and leave it idle. Do not open a game.
4. Open a normal, non-administrator PowerShell in this package directory.
5. Run:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Prepare-Interactive-Lab.ps1
```

6. Run the exact next command printed by preparation.
7. At the final prompt, type `INTERACTIVE SYSTEM CMD`.
8. In the new cmd window, run `whoami` and `whoami /all`.
9. Type `exit` in that cmd window when you are finished.
10. Revert or delete the disposable VM.

Do not reuse a run ID. Do not run this package on the host. Do not open a game during the sequence.
