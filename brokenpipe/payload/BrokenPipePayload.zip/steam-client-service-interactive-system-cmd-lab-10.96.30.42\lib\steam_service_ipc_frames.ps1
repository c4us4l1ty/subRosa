Set-StrictMode -Version Latest

$script:IpcOuterCommand = [byte]0x01
$script:IpcInterfaceSelector = [byte]0x01
$script:IpcSteamUser = [uint32]0
$script:IpcWhitelistMethod = [byte]0x3f
$script:IpcRunMethod = [byte]0x41
$script:IpcQueryMethod = [byte]0x42
$script:IpcWhitelistFencepost = [uint32]0xbe
$script:IpcRunFencepost = [uint32]0xc0
$script:IpcQueryFencepost = [uint32]0xc1

function ConvertTo-IpcAsciiBytes {
    param(
        [Parameter(Mandatory)]
        [AllowEmptyString()]
        [string]$Value
    )

    if ($Value.IndexOf([char]0) -ge 0) {
        throw 'IPC strings cannot contain embedded NUL characters.'
    }

    $bytes = [Text.Encoding]::ASCII.GetBytes($Value)
    if ([Text.Encoding]::ASCII.GetString($bytes) -cne $Value) {
        throw 'IPC strings must be ASCII.'
    }
    return ,([byte[]]$bytes)
}

function New-IpcStringBytes {
    param(
        [AllowEmptyString()]
        [AllowNull()]
        [object]$Value
    )

    if ($null -eq $Value) {
        return ,([byte[]](0x00))
    }
    if ($Value -isnot [string]) {
        throw 'IPC string value must be a string or NULL.'
    }
    $textBytes = ConvertTo-IpcAsciiBytes -Value $Value

    $output = [Collections.Generic.List[byte]]::new()
    if ($textBytes.Length -le 253) {
        $output.Add([byte]($textBytes.Length + 1))
    } else {
        $output.Add([byte]0xff)
    }
    $output.AddRange($textBytes)
    $output.Add([byte]0)
    return ,$output.ToArray()
}

function Read-IpcStringBytes {
    param(
        [Parameter(Mandatory)]
        [byte[]]$Bytes,
        [ValidateRange(0, [int]::MaxValue)]
        [int]$Offset
    )

    if ($Offset -ge $Bytes.Length) {
        throw 'IPC string length prefix is missing.'
    }

    $prefix = $Bytes[$Offset]
    if ($prefix -eq 0) {
        return [pscustomobject]@{
            value = $null
            offset = $Offset
            bytes_consumed = 1
            next_offset = $Offset + 1
            extended_length = $false
            is_null = $true
        }
    }
    $start = $Offset + 1
    if ($prefix -eq 0xff) {
        $terminatorIndex = $start
        while ($terminatorIndex -lt $Bytes.Length -and $Bytes[$terminatorIndex] -ne 0) {
            $terminatorIndex++
        }
        if ($terminatorIndex -ge $Bytes.Length) {
            throw 'Extended IPC string is not NUL terminated.'
        }
        $contentLength = $terminatorIndex - $start
        if ($contentLength -lt 254) {
            throw 'Extended IPC string is non-canonical for content shorter than 254 bytes.'
        }
        $nextOffset = $terminatorIndex + 1
        $extendedLength = $true
    } else {
        $count = [int]$prefix
        $terminatorIndex = $start + $count - 1
        $nextOffset = $terminatorIndex + 1
        if ($nextOffset -gt $Bytes.Length) {
            throw 'IPC string body is truncated.'
        }
        if ($Bytes[$terminatorIndex] -ne 0) {
            throw 'IPC string is not NUL terminated.'
        }
        $extendedLength = $false
    }
    for ($index = $start; $index -lt $terminatorIndex; $index++) {
        if ($Bytes[$index] -eq 0 -or $Bytes[$index] -gt 0x7f) {
            throw 'IPC string body is not canonical ASCII.'
        }
    }

    $textBytes = [byte[]]::new($terminatorIndex - $start)
    if ($textBytes.Length -gt 0) {
        [Array]::Copy($Bytes, $start, $textBytes, 0, $textBytes.Length)
    }
    return [pscustomobject]@{
        value = [Text.Encoding]::ASCII.GetString($textBytes)
        offset = $Offset
        bytes_consumed = $nextOffset - $Offset
        next_offset = $nextOffset
        extended_length = $extendedLength
        is_null = $false
    }
}

function Assert-IpcNonEmptyPath {
    param(
        [AllowNull()]
        [string]$Value,
        [string]$FieldName
    )

    if ([string]::IsNullOrEmpty($Value)) {
        throw "$FieldName must be a non-empty IPC string."
    }
}

function Get-IpcMethodLayout {
    param(
        [Parameter(Mandatory)]
        [ValidateSet('Whitelist', 'Run', 'Query')]
        [string]$Method,
        [Parameter(Mandatory)]
        [ValidateSet('Compact', 'CurrentClient')]
        [string]$SelectorForm
    )

    $layouts = @{
        Compact = @{
            Whitelist = @{ method = [uint32]0x3f; fencepost = [uint32]0xbe }
            Run = @{ method = [uint32]0x41; fencepost = [uint32]0xc0 }
            Query = @{ method = [uint32]0x42; fencepost = [uint32]0xc1 }
        }
        CurrentClient = @{
            Whitelist = @{ method = [uint32]0x1b7449c5; fencepost = [uint32]0x1b83cb83 }
            Run = @{
                method = [Convert]::ToUInt32('b1e810f9', 16)
                fencepost = [Convert]::ToUInt32('b1f810b9', 16)
            }
            Query = @{ method = [uint32]0x549d19df; fencepost = [uint32]0x54ad58a0 }
        }
    }
    $selected = $layouts[$SelectorForm][$Method]
    return [pscustomobject]@{
        method = [uint32]$selected.method
        fencepost = [uint32]$selected.fencepost
        selector_form = $SelectorForm
    }
}

function New-IpcInstallUtilsPrefix {
    param([uint32]$Method)
    return ,([byte[]](@(
        $script:IpcOuterCommand,
        $script:IpcInterfaceSelector
    ) + [BitConverter]::GetBytes($script:IpcSteamUser) + [BitConverter]::GetBytes($Method)))
}

function Assert-IpcInstallUtilsPrefix {
    param(
        [Parameter(Mandatory)]
        [byte[]]$Bytes,
        [uint32]$Method
    )

    if ($Bytes.Length -lt 10) {
        throw 'Install-utils payload is truncated before its method selector.'
    }
    $expected = New-IpcInstallUtilsPrefix -Method $Method
    for ($index = 0; $index -lt $expected.Length; $index++) {
        if ($Bytes[$index] -ne $expected[$index]) {
            throw 'Install-utils prefix does not match the expected selector layout.'
        }
    }
}

function Assert-IpcFencepost {
    param(
        [Parameter(Mandatory)]
        [byte[]]$Bytes,
        [int]$Offset,
        [uint32]$Expected
    )

    if ($Bytes.Length - $Offset -ne 4) {
        throw 'Install-utils payload has trailing or missing bytes around its fencepost.'
    }
    if ([BitConverter]::ToUInt32($Bytes, $Offset) -ne $Expected) {
        throw 'Install-utils payload fencepost does not match the selected method.'
    }
}

function New-IpcWhitelistPayload {
    param(
        [Parameter(Mandatory)]
        [AllowEmptyString()]
        [string]$SignedVdfPath,
        [Parameter(Mandatory)]
        [AllowEmptyString()]
        [string]$InstallRoot,
        [Parameter(Mandatory)]
        [ValidateSet('Compact', 'CurrentClient')]
        [string]$SelectorForm
    )

    Assert-IpcNonEmptyPath -Value $SignedVdfPath -FieldName 'SignedVdfPath'
    Assert-IpcNonEmptyPath -Value $InstallRoot -FieldName 'InstallRoot'
    $layout = Get-IpcMethodLayout -Method Whitelist -SelectorForm $SelectorForm
    return ,([byte[]](
        (New-IpcInstallUtilsPrefix -Method $layout.method) +
        (New-IpcStringBytes -Value $SignedVdfPath) +
        (New-IpcStringBytes -Value $InstallRoot) +
        [BitConverter]::GetBytes($layout.fencepost)
    ))
}

function Read-IpcWhitelistPayload {
    param(
        [Parameter(Mandatory)][byte[]]$Bytes,
        [Parameter(Mandatory)]
        [ValidateSet('Compact', 'CurrentClient')]
        [string]$SelectorForm
    )

    $layout = Get-IpcMethodLayout -Method Whitelist -SelectorForm $SelectorForm
    Assert-IpcInstallUtilsPrefix -Bytes $Bytes -Method $layout.method
    $first = Read-IpcStringBytes -Bytes $Bytes -Offset 10
    Assert-IpcNonEmptyPath -Value $first.value -FieldName 'SignedVdfPath'
    $second = Read-IpcStringBytes -Bytes $Bytes -Offset $first.next_offset
    Assert-IpcNonEmptyPath -Value $second.value -FieldName 'InstallRoot'
    Assert-IpcFencepost -Bytes $Bytes -Offset $second.next_offset -Expected $layout.fencepost
    return [pscustomobject]@{
        signed_vdf_path = $first.value
        install_root = $second.value
        method_selector = $layout.method
        fencepost = $layout.fencepost
        selector_form = $layout.selector_form
    }
}

function New-IpcRunPayload {
    param(
        [Parameter(Mandatory)]
        [AllowEmptyString()]
        [string]$VdfPath,
        [uint32]$Argument,
        [bool]$WireBoolean,
        [Parameter(Mandatory)]
        [ValidateSet('Compact', 'CurrentClient')]
        [string]$SelectorForm
    )

    Assert-IpcNonEmptyPath -Value $VdfPath -FieldName 'VdfPath'
    $layout = Get-IpcMethodLayout -Method Run -SelectorForm $SelectorForm
    $wireBooleanByte = if ($WireBoolean) { [byte]1 } else { [byte]0 }
    return ,([byte[]](
        (New-IpcInstallUtilsPrefix -Method $layout.method) +
        (New-IpcStringBytes -Value $VdfPath) +
        [BitConverter]::GetBytes($Argument) +
        $wireBooleanByte +
        [BitConverter]::GetBytes($layout.fencepost)
    ))
}

function Read-IpcRunPayload {
    param(
        [Parameter(Mandatory)][byte[]]$Bytes,
        [Parameter(Mandatory)]
        [ValidateSet('Compact', 'CurrentClient')]
        [string]$SelectorForm
    )

    $layout = Get-IpcMethodLayout -Method Run -SelectorForm $SelectorForm
    Assert-IpcInstallUtilsPrefix -Bytes $Bytes -Method $layout.method
    $path = Read-IpcStringBytes -Bytes $Bytes -Offset 10
    Assert-IpcNonEmptyPath -Value $path.value -FieldName 'VdfPath'
    if ($Bytes.Length - $path.next_offset -lt 9) {
        throw 'Run payload is truncated after its path argument.'
    }
    $argument = [BitConverter]::ToUInt32($Bytes, $path.next_offset)
    $wireBooleanByte = $Bytes[$path.next_offset + 4]
    if ($wireBooleanByte -notin @([byte]0, [byte]1)) {
        throw 'Run payload boolean must be encoded as exactly zero or one.'
    }
    $fencepostOffset = $path.next_offset + 5
    Assert-IpcFencepost -Bytes $Bytes -Offset $fencepostOffset -Expected $layout.fencepost
    return [pscustomobject]@{
        vdf_path = $path.value
        argument = $argument
        wire_boolean = $wireBooleanByte -eq 1
        method_selector = $layout.method
        fencepost = $layout.fencepost
        selector_form = $layout.selector_form
    }
}

function Get-IpcQueryPayload {
    param(
        [ValidateSet('Compact', 'CurrentClient')]
        [string]$SelectorForm = 'Compact'
    )
    $layout = Get-IpcMethodLayout -Method Query -SelectorForm $SelectorForm
    return ,([byte[]](
        (New-IpcInstallUtilsPrefix -Method $layout.method) +
        [BitConverter]::GetBytes($layout.fencepost)
    ))
}

function Read-IpcQueryPayload {
    param(
        [Parameter(Mandatory)][byte[]]$Bytes,
        [ValidateSet('Compact', 'CurrentClient')]
        [string]$SelectorForm = 'Compact'
    )

    $layout = Get-IpcMethodLayout -Method Query -SelectorForm $SelectorForm
    Assert-IpcInstallUtilsPrefix -Bytes $Bytes -Method $layout.method
    Assert-IpcFencepost -Bytes $Bytes -Offset 10 -Expected $layout.fencepost
    return [pscustomobject]@{
        method_selector = $layout.method
        fencepost = $layout.fencepost
        selector_form = $layout.selector_form
    }
}

function New-IpcFrame {
    param([AllowNull()][byte[]]$Payload)

    if ($null -eq $Payload -or $Payload.Length -eq 0) {
        throw 'IPC payload must not be null or empty.'
    }
    if ($Payload.Length -gt [uint32]::MaxValue) {
        throw 'IPC payload is too large to frame.'
    }
    return ,([byte[]]([BitConverter]::GetBytes([uint32]$Payload.Length) + $Payload))
}

function ConvertTo-IpcHexString {
    param([Parameter(Mandatory)][byte[]]$Bytes)
    return (($Bytes | ForEach-Object { $_.ToString('x2') }) -join ' ')
}

function Get-IpcSha256 {
    param([Parameter(Mandatory)][byte[]]$Bytes)

    $sha256 = [Security.Cryptography.SHA256]::Create()
    try {
        return ([BitConverter]::ToString($sha256.ComputeHash($Bytes))).Replace('-', '')
    } finally {
        $sha256.Dispose()
    }
}

function Get-IpcFrameFixtureRecord {
    param(
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$CaseId,
        [AllowNull()]
        [byte[]]$Payload
    )

    if ($null -eq $Payload -or $Payload.Length -eq 0) {
        throw 'Fixture payload must not be null or empty.'
    }
    $frame = New-IpcFrame -Payload $Payload
    return [pscustomobject]@{
        case_id = $CaseId
        payload_hex = ConvertTo-IpcHexString -Bytes $Payload
        frame_hex = ConvertTo-IpcHexString -Bytes $frame
        payload_length = $Payload.Length
        frame_length = $frame.Length
        payload_sha256 = Get-IpcSha256 -Bytes $Payload
        frame_sha256 = Get-IpcSha256 -Bytes $frame
        fixture_only = $true
        ipc_sent = $false
    }
}

function Read-IpcFrame {
    param([Parameter(Mandatory)][byte[]]$Bytes)

    if ($Bytes.Length -lt 4) {
        throw 'IPC frame is shorter than its length prefix.'
    }
    $payloadLength = [uint64][BitConverter]::ToUInt32($Bytes, 0)
    if ($payloadLength -ne ($Bytes.Length - 4)) {
        throw 'IPC frame payload length does not match the supplied bytes.'
    }
    $payload = [byte[]]::new([int]$payloadLength)
    if ($payload.Length -gt 0) {
        [Array]::Copy($Bytes, 4, $payload, 0, $payload.Length)
    }
    return ,$payload
}

function Read-IpcWhitelistResponse {
    param([Parameter(Mandatory)][byte[]]$Bytes)

    if ($Bytes.Length -ne 5 -or $Bytes[0] -ne $script:IpcOuterCommand) {
        throw 'Whitelist response is not the exact command-one integer layout.'
    }
    return [BitConverter]::ToInt32($Bytes, 1)
}

function Read-IpcRunResponse {
    param([Parameter(Mandatory)][byte[]]$Bytes)

    if ($Bytes.Length -ne 2 -or $Bytes[0] -ne $script:IpcOuterCommand) {
        throw 'Run response is not the exact command-one boolean layout.'
    }
    if ($Bytes[1] -notin @([byte]0, [byte]1)) {
        throw 'Run response boolean must be encoded as exactly zero or one.'
    }
    return $Bytes[1] -eq 1
}

function Read-IpcQueryResponse {
    param([Parameter(Mandatory)][byte[]]$Bytes)

    if ($Bytes.Length -ne 5 -or $Bytes[0] -ne $script:IpcOuterCommand) {
        throw 'Query response is not the exact command-one integer layout.'
    }
    return [BitConverter]::ToInt32($Bytes, 1)
}
